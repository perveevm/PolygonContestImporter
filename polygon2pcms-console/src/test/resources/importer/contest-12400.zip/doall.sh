echo [INFO]: Building problem 'coconuts-keldysh'.
cd problems/coconuts-keldysh
./doall.sh
cd -

echo [INFO]: Building problem 'numpart-keldysh'.
cd problems/numpart-keldysh
./doall.sh
cd -

echo [INFO]: Building problem 'flag-keldysh'.
cd problems/flag-keldysh
./doall.sh
cd -

echo [INFO]: Building problem 'ioi-place-keldysh'.
cd problems/ioi-place-keldysh
./doall.sh
cd -

echo [INFO]: Building problem 'rectangles-keldysh'.
cd problems/rectangles-keldysh
./doall.sh
cd -

echo [INFO]: Building russian contest statement.
cd statements/russian
./doall.sh
cd -

