#!/usr/bin/python3
# Dmitry _kun_ Sayutin (2019)

n, m, q = map(int, input().split())

quant = [0 for i in range(m)]
for elem in map(int, input().split()):
    quant[elem - 1] += 1

lst = list(zip(quant, range(m)))
lst.sort()

for qu in range(q):
    year = int(input()) - n - 1
    
    ans = None

    if year >= (m * max(quant) - n):
        ans = (year - (m * max(quant) - n)) % m
    else:        
        ptr = 0

        for val in range(0, 1000 * 1000):
            while lst[ptr][0] == val:
                ptr += 1

            if year >= ptr:
                year -= ptr
                continue

            eligible = [y for (x, y) in lst[:ptr]]
            eligible.sort()

            ans = eligible[year]
            break

    print(ans + 1)

