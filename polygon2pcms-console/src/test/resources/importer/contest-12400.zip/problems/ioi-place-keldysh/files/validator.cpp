#include "testlib.h"

typedef long long int ll;

using namespace std;

struct group {
    string name;
    int MAX_N;
    int MAX_M;
    int MAX_Q;
    ll MAX_K;
};

const int CNT_GROUP = 6;

group groups[CNT_GROUP] =
{
    {
        .name = "0",
        .MAX_N = 500 * 1000,
        .MAX_M = 500 * 1000,
        .MAX_Q = 20,
        .MAX_K = 1000ll * 1000ll * 1000ll * 1000ll * 1000ll * 1000ll,
    },
    {
        .name = "1",
        .MAX_N = 100,
        .MAX_M = 100,
        .MAX_Q = 20,
        .MAX_K = 200ll,
    },
    {
        .name = "2",
        .MAX_N = 100,
        .MAX_M = 100,
        .MAX_Q = 20,
        .MAX_K = 1000ll * 1000ll * 1000ll * 1000ll * 1000ll * 1000ll,
    },
    {
        .name = "3",
        .MAX_N = 100 * 1000,
        .MAX_M = 100 * 1000,
        .MAX_Q = 20,
        .MAX_K = 250ll * 1000ll,
    },
    {
        .name = "4",
        .MAX_N = 100 * 1000,
        .MAX_M = 100 * 1000,
        .MAX_Q = 20,
        .MAX_K = 1000ll * 1000ll * 1000ll * 1000ll * 1000ll * 1000ll,
    },
    {
        .name = "5",
        .MAX_N = 500 * 1000,
        .MAX_M = 500 * 1000,
        .MAX_Q = 20,
        .MAX_K = 1000ll * 1000ll * 1000ll * 1000ll * 1000ll * 1000ll,
    },
};

int main(int argc, char **argv) {
    registerValidation(argc, argv);

    int group_id = -1;

    for (int i = 0; i < CNT_GROUP; ++i) {
        if (groups[i].name == validator.group()) {
            group_id = i;
            break;
        }
    }

    ensuref(group_id != -1, "no group for this test");

    group& currentGroup = groups[group_id];

    int n = inf.readInt(1, currentGroup.MAX_N, "n");
    inf.readSpace();
    int m = inf.readInt(1, currentGroup.MAX_M, "m");
    inf.readSpace();
    int q = inf.readInt(1, currentGroup.MAX_Q, "q");
    inf.readEoln();

    for (int i = 0; i < n; ++i) {
        inf.readInt(1, m, "a_" + vtos(i + 1));
        if (i == n - 1) {
            inf.readEoln();
        } else {
            inf.readSpace();
        }
    }

    for (int i = 0; i < q; ++i) {
        inf.readLong(n + 1, currentGroup.MAX_K, "k_" + vtos(i + 1));
        inf.readEoln();
    }

    inf.readEof();

    return 0;
}

