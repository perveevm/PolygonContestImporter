#include "testlib.h"
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <string>
#include <string.h>
#include <vector>
#include <stack>
#include <queue>
#include <deque>
#include <set>
#include <map>
#include <assert.h>
#include <algorithm>
#include <iomanip>
#include <time.h>
#include <math.h>
#include <bitset>

#pragma comment(linker, "/STACK:256000000")

using namespace std;

typedef long long int ll;
typedef long double ld;

const int INF = 1000 * 1000 * 1000 + 21;
const ll LLINF = (1ll << 60) + 5;
const int MOD = 1000 * 1000 * 1000 + 7;


int main(int argc, char **argv) {
    registerGen(argc, argv, 1);

    int n = atoi(argv[1]);
    int m = atoi(argv[2]);
    int q = atoi(argv[3]);
    int number_of_lens = atoi(argv[4]);
    ll max_k = atoll(argv[5]);
    int nm_prob = atoi(argv[6]);

    ll sum = 0;
    vector<int> lens(number_of_lens);
    vector<int> at_len(number_of_lens);
    set<int> used;
    for (int i = 0; i < number_of_lens; ++i) {
        lens[i] = i + 1;
        sum += i + 1;

        int now = rnd.next(1, m);
        while (used.find(now) != used.end()) {
            now = rnd.next(1, m);
        }
        used.insert(now);
        at_len[i] = now;
    }

    assert(sum <= n);
    while (sum < n) {
        ++lens.back();
        ++sum;
    }

    vector<int> arr(n);
    int ptr = 0;
    for (int i = 0; i < number_of_lens; ++i) {
        for (int j = 0; j < (int)lens[i]; ++j) {
            arr[ptr++] = at_len[i];
        }
    }
    assert(ptr == n);
    shuffle(arr.begin(), arr.end());


    printf("%d %d %d\n", n, m, q);
    for (int i = 0; i < n; ++i) {
        printf("%d%c", arr[i], " \n"[i == n - 1]);
    }

    for (int i = 0; i < q; ++i) {
        ll k = n + 1;
        if (rnd.next(1, 100) <= nm_prob) {
            k = rnd.next((ll)n + 1, min((ll)n * m, max_k));
        } else {
            k = rnd.next((ll)n + 1, max_k);
        }

        printf("%lld\n", k);
    }

    return 0;
}

