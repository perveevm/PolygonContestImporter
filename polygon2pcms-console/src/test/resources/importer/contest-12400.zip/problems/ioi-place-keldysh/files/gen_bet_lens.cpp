#include "testlib.h"
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <string>
#include <string.h>
#include <vector>
#include <stack>
#include <queue>
#include <deque>
#include <set>
#include <map>
#include <assert.h>
#include <algorithm>
#include <iomanip>
#include <time.h>
#include <math.h>
#include <bitset>

#pragma comment(linker, "/STACK:256000000")

using namespace std;

typedef long long int ll;
typedef long double ld;

const int INF = 1000 * 1000 * 1000 + 21;
const ll LLINF = (1ll << 60) + 5;
const int MOD = 1000 * 1000 * 1000 + 7;


int main(int argc, char **argv) {
    registerGen(argc, argv, 1);

    int n = atoi(argv[1]);
    int m = atoi(argv[2]);
    int q = atoi(argv[3]);
    int min_len = atoi(argv[4]);
    int max_len = atoi(argv[5]);
    int rest = atoi(argv[6]);
    ll max_k = atoll(argv[7]);
    int nm_prob = atoi(argv[8]);

    ll sum = 0;
    vector<int> lens;
    vector<int> at_len;
    set<int> used;
    while (sum + min_len <= n) {
        int new_len = rnd.next((ll)min_len, min((ll)max_len, n - sum));
        lens.push_back(new_len);
        sum += new_len;

        int now = rnd.next(1, m);
        while (used.find(now) != used.end()) {
            now = rnd.next(1, m);
        }
        used.insert(now);
        at_len.push_back(now);
    }

    if (rest) {
        while (sum < n) {
            int new_len = rnd.next(1ll, n - sum);
            lens.push_back(new_len);
            sum += new_len;

            int now = rnd.next(1, m);
            while (used.find(now) != used.end()) {
                now = rnd.next(1, m);
            }
            used.insert(now);
            at_len.push_back(now);
        }
    } else {
        int new_len = n - sum;
        lens.push_back(new_len);
        sum += new_len;

        int now = rnd.next(1, m);
        while (used.find(now) != used.end()) {
            now = rnd.next(1, m);
        }
        used.insert(now);
        at_len.push_back(now);
    }

    assert(sum == n);

    vector<int> arr(n);
    int ptr = 0;
    for (int i = 0; i < (int)lens.size(); ++i) {
        for (int j = 0; j < (int)lens[i]; ++j) {
            arr[ptr++] = at_len[i];
        }
    }
    assert(ptr == n);
    shuffle(arr.begin(), arr.end());

    printf("%d %d %d\n", n, m, q);
    for (int i = 0; i < n; ++i) {
        printf("%d%c", arr[i], " \n"[i == n - 1]);
    }

    for (int i = 0; i < q; ++i) {
        ll k = n + 1;
        if (rnd.next(1, 100) <= nm_prob) {
            k = rnd.next((ll)n + 1, (ll)n * m);
        } else {
            k = rnd.next((ll)n + 1, max_k);
        }

        printf("%lld\n", k);
    }

    return 0;
}

