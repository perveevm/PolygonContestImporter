#!/usr/bin/env bash
#   *** validation ***
scripts/run-validator-tests.sh
scripts/run-checker-tests.sh

#    *** tests ***
mkdir -p tests
echo "Generating test #5"
scripts/gen-input-via-stdout.sh "wine files/gen_random.exe 100 99 20 200 0" "tests/05" 5
echo "Generating test #6"
scripts/gen-input-via-stdout.sh "wine files/gen_random.exe 100 16 20 200 0" "tests/06" 6
echo "Generating test #7"
scripts/gen-input-via-stdout.sh "wine files/gen_diff_lens.exe 100 41 20 13 200 0" "tests/07" 7
echo "Generating test #8"
scripts/gen-input-via-stdout.sh "wine files/gen_bet_lens.exe 20 9 18 20 20 0 200 0 | wine files/add_random.exe 1 180 180 | wine files/add_random.exe 1 172 172" "tests/08" 8
echo "Generating test #9"
scripts/gen-input-via-stdout.sh "wine files/gen_bet_lens.exe 100 11 20 30 40 1 200 0" "tests/09" 9
echo "Generating test #10"
scripts/gen-input-via-stdout.sh "wine files/gen_random.exe 100 51 0 0 0 | wine files/add_on_nm.exe 10 -1 -1 200 1 0 | wine files/add_on_nm.exe 5 -1 -1 200 1 1 | wine files/add_on_nm.exe 5 -1 -1 200 0 0" "tests/10" 10
echo "Generating test #11"
scripts/gen-input-via-stdout.sh "wine files/gen_bet_lens.exe 100 6 0 20 23 0 0 0 | wine files/add_on_nm.exe 10 -1 -1 200 1 0 | wine files/add_on_nm.exe 5 -1 -1 200 1 1 | wine files/add_on_nm.exe 5 -1 -1 200 0 0" "tests/11" 11
echo "Generating test #12"
scripts/gen-input-via-stdout.sh "wine files/gen_diff_lens.exe 100 21 0 13 0 0 | wine files/add_on_nm.exe 10 -1 -1 200 1 0 | wine files/add_on_nm.exe 5 -1 -1 200 1 1 | wine files/add_on_nm.exe 5 -1 -1 200 0 0" "tests/12" 12
echo "Generating test #13"
scripts/gen-input-via-stdout.sh "wine files/gen_random.exe 100 96 18 1000000000000000000 | wine files/add_random.exe 1 180 180 | wine files/add_random.exe 1 1000000000000000000 1000000000000000000" "tests/13" 13
echo "Generating test #14"
scripts/gen-input-via-stdout.sh "wine files/gen_random.exe 100 74 0 0 0 | wine files/add_on_nm.exe 5 -1 -1 200 1 0 | wine files/add_on_nm.exe 5 -1 -1 200 1 1 | wine files/add_on_nm.exe 5 -1 -1 200 0 0 | wine files/add_random.exe 5 10000000 1000000000000000000" "tests/14" 14
echo "Generating test #15"
scripts/gen-input-via-stdout.sh "wine files/gen_bet_lens.exe 100 17 0 10 13 0 0 0 | wine files/add_on_nm.exe 5 -1 -1 200 1 0 | wine files/add_on_nm.exe 5 -1 -1 200 1 1 | wine files/add_on_nm.exe 5 -1 -1 200 0 0 | wine files/add_random.exe 5 100031000 1000000000000000000" "tests/15" 15
echo "Generating test #16"
scripts/gen-input-via-stdout.sh "wine files/gen_diff_lens.exe 100 21 0 13 0 0 kek | wine files/add_on_nm.exe 5 -1 -1 200 1 0 f | wine files/add_on_nm.exe 5 -1 -1 200 1 1 f | wine files/add_on_nm.exe 5 -1 -1 200 0 0 f | wine files/add_random.exe 5 10002000 1000000000000000000" "tests/16" 16
echo "Generating test #17"
scripts/gen-input-via-stdout.sh "wine files/gen_random.exe 100 100 0 0 0 | wine files/add_on_nm.exe 3 -1 -1 200 1 0 | wine files/add_on_nm.exe 3 -1 -1 200 1 1 | wine files/add_on_nm.exe 6 -1 -1 200 0 0 | wine files/add_random.exe 7 10000000 1000000000000000000 | wine files/add_random.exe 1 1000000000000000000 1000000000000000000" "tests/17" 17
echo "Generating test #18"
scripts/gen-input-via-stdout.sh "wine files/gen_random.exe 100000 99997 20 250000 0" "tests/18" 18
echo "Generating test #19"
scripts/gen-input-via-stdout.sh "wine files/gen_random.exe 100000 8123 20 250000 0" "tests/19" 19
echo "Generating test #20"
scripts/gen-input-via-stdout.sh "wine files/gen_diff_lens.exe 100000 98354 20 446 250000 0" "tests/20" 20
echo "Generating test #21"
scripts/gen-input-via-stdout.sh "wine files/gen_bet_lens.exe 40000 6 18 40000 40000 0 250000 0 | wine files/add_random.exe 1 240000 240000 | wine files/add_random.exe 1 200000 200000" "tests/21" 21
echo "Generating test #22"
scripts/gen-input-via-stdout.sh "wine files/gen_bet_lens.exe 100000 54363 20 3000 9000 1 250000 0" "tests/22" 22
echo "Generating test #23"
scripts/gen-input-via-stdout.sh "wine files/gen_bet_lens.exe 100000 100000 0 13000 18000 1 0 0 | wine files/add_random.exe 20 249900 250000" "tests/23" 23
echo "Generating test #24"
scripts/gen-input-via-stdout.sh "wine files/gen_random.exe 100000 51124 0 0 0 | wine files/add_on_nm.exe 10 -1 -1 250000 1 0 | wine files/add_on_nm.exe 5 -1 -1 250000 1 1 | wine files/add_on_nm.exe 5 -1 -1 250000 0 0" "tests/24" 24
echo "Generating test #25"
scripts/gen-input-via-stdout.sh "wine files/gen_bet_lens.exe 100000 623 0 200 230 0 0 0 | wine files/add_on_nm.exe 10 -1 -1 250000 1 0 | wine files/add_on_nm.exe 5 -1 -1 250000 1 1 | wine files/add_on_nm.exe 5 -1 -1 250000 0 0" "tests/25" 25
echo "Generating test #26"
scripts/gen-input-via-stdout.sh "wine files/gen_bet_lens.exe 100000 83924 0 200 500 0 0 0 | wine files/add_on_nm.exe 5 -1 -1 250000 1 0 | wine files/add_on_nm.exe 5 -1 -1 250000 1 1 | wine files/add_on_nm.exe 10 -1 -1 250000 0 0" "tests/26" 26
echo "Generating test #27"
scripts/gen-input-via-stdout.sh "wine files/gen_diff_lens.exe 100000 18453 0 446 0 0 | wine files/add_on_nm.exe 10 -1 -1 250000 1 0 | wine files/add_on_nm.exe 5 -1 -1 250000 1 1 | wine files/add_on_nm.exe 5 -1 -1 250000 0 0" "tests/27" 27
echo "Generating test #28"
scripts/gen-input-via-stdout.sh "wine files/gen_random.exe 100000 99999 15 1000000000000000000 | wine files/add_random.exe 4 100000000 10000000000 | wine files/add_random.exe 1 1000000000000000000 1000000000000000000" "tests/28" 28
echo "Generating test #29"
scripts/gen-input-via-stdout.sh "wine files/gen_diff_lens.exe 100000 98354 15 446 1000000000000000000 0 | wine files/add_random.exe 4 100000000 10000000000 | wine files/add_random.exe 1 1000000000000000000 1000000000000000000" "tests/29" 29
echo "Generating test #30"
scripts/gen-input-via-stdout.sh "wine files/gen_diff_lens.exe 100000 98355 0 446 0 0 | wine files/add_on_nm.exe 15 94356 100000 -1 0 0 | wine files/add_on_nm.exe 5 99356 100000 -1 1 0" "tests/30" 30
echo "Generating test #31"
scripts/gen-input-via-stdout.sh "wine files/gen_diff_lens.exe 100000 98354 0 445 0 0 | wine files/add_on_nm.exe 5 99000 100000 -1 0 0 | wine files/add_on_nm.exe 15 0 446 -1 1 0" "tests/31" 31
echo "Generating test #32"
scripts/gen-input-via-stdout.sh "wine files/gen_bet_lens.exe 100000 99324 0 100000 100000 0 0 0 | wine files/add_on_nm.exe 10 0 99999 -1 0 0 | wine files/add_on_nm.exe 3 100000 100000 -1 1 0 | wine files/add_on_nm.exe 7 100000 100000 -1 0 0" "tests/32" 32
echo "Generating test #33"
scripts/gen-input-via-stdout.sh "wine files/gen_bet_lens.exe 100000 623 0 200 230 0 0 0 | wine files/add_on_nm.exe 10 65757 93245 -1 1 0 | wine files/add_on_nm.exe 5 -1 -1 -1 1 1 | wine files/add_on_nm.exe 5 99923 100000 -1 0 0" "tests/33" 33
echo "Generating test #34"
scripts/gen-input-via-stdout.sh "wine files/gen_bet_lens.exe 100000 83924 0 200 500 0 0 0 | wine files/add_on_nm.exe 10 65757 93245 -1 1 0 | wine files/add_on_nm.exe 5 -1 -1 -1 1 1 | wine files/add_on_nm.exe 5 99923 100000 -1 0 0" "tests/34" 34
echo "Generating test #35"
scripts/gen-input-via-stdout.sh "wine files/gen_bet_lens.exe 100000 2345 0 20000 23000 0 0 0 | wine files/add_on_nm.exe 10 20000 23000 -1 1 0 | wine files/add_on_nm.exe 5 -1 -1 -1 1 1 | wine files/add_on_nm.exe 3 99323 100000 -1 0 0 | wine files/add_random.exe 2 100000000000000000 1000000000000000000" "tests/35" 35
echo "Generating test #36"
scripts/gen-input-via-stdout.sh "wine files/gen_bet_lens.exe 100000 89924 0 8000 8800 0 0 0 | wine files/add_on_nm.exe 10 24757 93245 -1 1 0 | wine files/add_on_nm.exe 5 -1 -1 -1 1 1 | wine files/add_on_nm.exe 3 99323 100000 -1 0 0 | wine files/add_random.exe 2 100000000000000000 1000000000000000000" "tests/36" 36
echo "Generating test #37"
scripts/gen-input-via-stdout.sh "wine files/gen_random.exe 100000 100000 1 1000000000000000000 0 | wine files/add_on_nm.exe 10 65757 93245 -1 1 0 | wine files/add_on_nm.exe 5 -1 -1 -1 1 1 | wine files/add_on_nm.exe 4 99923 100000 -1 0 0" "tests/37" 37
echo "Generating test #38"
scripts/gen-input-via-stdout.sh "wine files/gen_random.exe 500000 499999 15 1000000000000000000 | wine files/add_random.exe 4 100000000 10000000000 | wine files/add_random.exe 1 1000000000000000000 1000000000000000000" "tests/38" 38
echo "Generating test #39"
scripts/gen-input-via-stdout.sh "wine files/gen_diff_lens.exe 500000 498354 15 999 1000000000000000000 0 | wine files/add_random.exe 4 100000000 10000000000 | wine files/add_random.exe 1 1000000000000000000 1000000000000000000" "tests/39" 39
echo "Generating test #40"
scripts/gen-input-via-stdout.sh "wine files/gen_diff_lens.exe 500000 498355 0 999 0 0 | wine files/add_on_nm.exe 15 494356 500000 -1 0 0 | wine files/add_on_nm.exe 5 499356 500000 -1 1 0" "tests/40" 40
echo "Generating test #41"
scripts/gen-input-via-stdout.sh "wine files/gen_diff_lens.exe 500000 498354 0 998 0 0 | wine files/add_on_nm.exe 5 499000 500000 -1 0 0 | wine files/add_on_nm.exe 15 0 998 -1 1 0" "tests/41" 41
echo "Generating test #42"
scripts/gen-input-via-stdout.sh "wine files/gen_bet_lens.exe 500000 499324 0 500000 500000 0 0 0 | wine files/add_on_nm.exe 10 0 499999 -1 0 0 | wine files/add_on_nm.exe 3 500000 500000 -1 1 0 | wine files/add_on_nm.exe 7 500000 500000 -1 0 0" "tests/42" 42
echo "Generating test #43"
scripts/gen-input-via-stdout.sh "wine files/gen_bet_lens.exe 500000 3623 0 200 230 0 0 0 | wine files/add_on_nm.exe 10 365757 493245 -1 1 0 | wine files/add_on_nm.exe 5 -1 -1 -1 1 1 | wine files/add_on_nm.exe 5 499923 500000 -1 0 0" "tests/43" 43
echo "Generating test #44"
scripts/gen-input-via-stdout.sh "wine files/gen_bet_lens.exe 500000 83924 0 200 500 0 0 0 | wine files/add_on_nm.exe 10 365757 493245 -1 1 0 | wine files/add_on_nm.exe 5 -1 -1 -1 1 1 | wine files/add_on_nm.exe 5 499923 500000 -1 0 0" "tests/44" 44
echo "Generating test #45"
scripts/gen-input-via-stdout.sh "wine files/gen_bet_lens.exe 500000 7345 0 20000 23000 0 0 0 | wine files/add_on_nm.exe 10 20000 23000 -1 1 0 | wine files/add_on_nm.exe 5 -1 -1 -1 1 1 | wine files/add_on_nm.exe 3 499323 500000 -1 0 0 | wine files/add_random.exe 2 100000000000000000 1000000000000000000" "tests/45" 45
echo "Generating test #46"
scripts/gen-input-via-stdout.sh "wine files/gen_bet_lens.exe 500000 489924 0 8000 8800 0 0 0 | wine files/add_on_nm.exe 10 124757 493245 -1 1 0 | wine files/add_on_nm.exe 5 -1 -1 -1 1 1 | wine files/add_on_nm.exe 3 499323 500000 -1 0 0 | wine files/add_random.exe 2 100000000000000000 1000000000000000000" "tests/46" 46
echo "Generating test #47"
scripts/gen-input-via-stdout.sh "wine files/gen_random.exe 500000 500000 1 1000000000000000000 0 | wine files/add_on_nm.exe 10 265757 493245 -1 1 0 | wine files/add_on_nm.exe 5 -1 -1 -1 1 1 | wine files/add_on_nm.exe 4 499923 500000 -1 0 0" "tests/47" 47
echo "Generating test #48"
scripts/gen-input-via-stdout.sh "wine files/gen_diff_lens.exe 500000 499999 0 999 0 0 | wine files/add_on_nm.exe 16 494356 500000 -1 0 0 | wine files/add_on_nm.exe 2 0 999 -1 1 0 | wine files/add_on_nm.exe 1 0 999 -1 0 0 | wine files/add_random.exe 1 10000000000000000 1000000000000000000" "tests/48" 48
echo "Generating test #49"
scripts/gen-input-via-stdout.sh "wine files/gen_diff_lens.exe 500000 500000 0 980 0 0 | wine files/add_on_nm.exe 17 394356 450000 -1 0 0 | wine files/add_on_nm.exe 1 0 999 -1 1 0 | wine files/add_on_nm.exe 1 0 999 -1 0 0 | wine files/add_random.exe 1 10000000000000000 1000000000000000000" "tests/49" 49
echo "Generating test #50"
scripts/gen-input-via-stdout.sh "wine files/gen_diff_lens.exe 500000 499555 0 867 0 0 | wine files/add_on_nm.exe 17 434356 500000 -1 0 0 | wine files/add_on_nm.exe 1 0 999 -1 1 0 | wine files/add_on_nm.exe 1 0 999 -1 0 0 | wine files/add_random.exe 1 10000000000000000 1000000000000000000" "tests/50" 50
echo "Generating test #51"
scripts/gen-input-via-stdout.sh "wine files/gen_diff_lens.exe 500000 499995 0 800 0 0 | wine files/add_on_nm.exe 18 499356 500000 -1 0 0 | wine files/add_on_nm.exe 1 0 999 -1 0 0 | wine files/add_random.exe 1 10000000000000000 1000000000000000000" "tests/51" 51
echo "Generating test #52"
scripts/gen-input-via-stdout.sh "wine files/gen_diff_lens.exe 500000 491999 0 999 0 0 | wine files/add_on_nm.exe 19 499999 500000 -1 0 0 | wine files/add_random.exe 1 10000000000000000 1000000000000000000" "tests/52" 52
echo ""
echo "Generating answer for test #1"
scripts/gen-answer.sh tests/01 tests/01.a "tests" "0"
echo ""
echo "Generating answer for test #2"
scripts/gen-answer.sh tests/02 tests/02.a "tests" "0"
echo ""
echo "Generating answer for test #3"
scripts/gen-answer.sh tests/03 tests/03.a "tests" "1"
echo ""
echo "Generating answer for test #4"
scripts/gen-answer.sh tests/04 tests/04.a "tests" "1"
echo ""
echo "Generating answer for test #5"
scripts/gen-answer.sh tests/05 tests/05.a "tests" "1"
echo ""
echo "Generating answer for test #6"
scripts/gen-answer.sh tests/06 tests/06.a "tests" "1"
echo ""
echo "Generating answer for test #7"
scripts/gen-answer.sh tests/07 tests/07.a "tests" "1"
echo ""
echo "Generating answer for test #8"
scripts/gen-answer.sh tests/08 tests/08.a "tests" "1"
echo ""
echo "Generating answer for test #9"
scripts/gen-answer.sh tests/09 tests/09.a "tests" "1"
echo ""
echo "Generating answer for test #10"
scripts/gen-answer.sh tests/10 tests/10.a "tests" "1"
echo ""
echo "Generating answer for test #11"
scripts/gen-answer.sh tests/11 tests/11.a "tests" "1"
echo ""
echo "Generating answer for test #12"
scripts/gen-answer.sh tests/12 tests/12.a "tests" "1"
echo ""
echo "Generating answer for test #13"
scripts/gen-answer.sh tests/13 tests/13.a "tests" "2"
echo ""
echo "Generating answer for test #14"
scripts/gen-answer.sh tests/14 tests/14.a "tests" "2"
echo ""
echo "Generating answer for test #15"
scripts/gen-answer.sh tests/15 tests/15.a "tests" "2"
echo ""
echo "Generating answer for test #16"
scripts/gen-answer.sh tests/16 tests/16.a "tests" "2"
echo ""
echo "Generating answer for test #17"
scripts/gen-answer.sh tests/17 tests/17.a "tests" "2"
echo ""
echo "Generating answer for test #18"
scripts/gen-answer.sh tests/18 tests/18.a "tests" "3"
echo ""
echo "Generating answer for test #19"
scripts/gen-answer.sh tests/19 tests/19.a "tests" "3"
echo ""
echo "Generating answer for test #20"
scripts/gen-answer.sh tests/20 tests/20.a "tests" "3"
echo ""
echo "Generating answer for test #21"
scripts/gen-answer.sh tests/21 tests/21.a "tests" "3"
echo ""
echo "Generating answer for test #22"
scripts/gen-answer.sh tests/22 tests/22.a "tests" "3"
echo ""
echo "Generating answer for test #23"
scripts/gen-answer.sh tests/23 tests/23.a "tests" "3"
echo ""
echo "Generating answer for test #24"
scripts/gen-answer.sh tests/24 tests/24.a "tests" "3"
echo ""
echo "Generating answer for test #25"
scripts/gen-answer.sh tests/25 tests/25.a "tests" "3"
echo ""
echo "Generating answer for test #26"
scripts/gen-answer.sh tests/26 tests/26.a "tests" "3"
echo ""
echo "Generating answer for test #27"
scripts/gen-answer.sh tests/27 tests/27.a "tests" "3"
echo ""
echo "Generating answer for test #28"
scripts/gen-answer.sh tests/28 tests/28.a "tests" "4"
echo ""
echo "Generating answer for test #29"
scripts/gen-answer.sh tests/29 tests/29.a "tests" "4"
echo ""
echo "Generating answer for test #30"
scripts/gen-answer.sh tests/30 tests/30.a "tests" "4"
echo ""
echo "Generating answer for test #31"
scripts/gen-answer.sh tests/31 tests/31.a "tests" "4"
echo ""
echo "Generating answer for test #32"
scripts/gen-answer.sh tests/32 tests/32.a "tests" "4"
echo ""
echo "Generating answer for test #33"
scripts/gen-answer.sh tests/33 tests/33.a "tests" "4"
echo ""
echo "Generating answer for test #34"
scripts/gen-answer.sh tests/34 tests/34.a "tests" "4"
echo ""
echo "Generating answer for test #35"
scripts/gen-answer.sh tests/35 tests/35.a "tests" "4"
echo ""
echo "Generating answer for test #36"
scripts/gen-answer.sh tests/36 tests/36.a "tests" "4"
echo ""
echo "Generating answer for test #37"
scripts/gen-answer.sh tests/37 tests/37.a "tests" "4"
echo ""
echo "Generating answer for test #38"
scripts/gen-answer.sh tests/38 tests/38.a "tests" "5"
echo ""
echo "Generating answer for test #39"
scripts/gen-answer.sh tests/39 tests/39.a "tests" "5"
echo ""
echo "Generating answer for test #40"
scripts/gen-answer.sh tests/40 tests/40.a "tests" "5"
echo ""
echo "Generating answer for test #41"
scripts/gen-answer.sh tests/41 tests/41.a "tests" "5"
echo ""
echo "Generating answer for test #42"
scripts/gen-answer.sh tests/42 tests/42.a "tests" "5"
echo ""
echo "Generating answer for test #43"
scripts/gen-answer.sh tests/43 tests/43.a "tests" "5"
echo ""
echo "Generating answer for test #44"
scripts/gen-answer.sh tests/44 tests/44.a "tests" "5"
echo ""
echo "Generating answer for test #45"
scripts/gen-answer.sh tests/45 tests/45.a "tests" "5"
echo ""
echo "Generating answer for test #46"
scripts/gen-answer.sh tests/46 tests/46.a "tests" "5"
echo ""
echo "Generating answer for test #47"
scripts/gen-answer.sh tests/47 tests/47.a "tests" "5"
echo ""
echo "Generating answer for test #48"
scripts/gen-answer.sh tests/48 tests/48.a "tests" "5"
echo ""
echo "Generating answer for test #49"
scripts/gen-answer.sh tests/49 tests/49.a "tests" "5"
echo ""
echo "Generating answer for test #50"
scripts/gen-answer.sh tests/50 tests/50.a "tests" "5"
echo ""
echo "Generating answer for test #51"
scripts/gen-answer.sh tests/51 tests/51.a "tests" "5"
echo ""
echo "Generating answer for test #52"
scripts/gen-answer.sh tests/52 tests/52.a "tests" "5"
echo ""

