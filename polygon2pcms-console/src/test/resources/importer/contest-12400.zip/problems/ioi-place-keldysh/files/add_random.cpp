#include "testlib.h"
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <string>
#include <string.h>
#include <vector>
#include <stack>
#include <queue>
#include <deque>
#include <set>
#include <map>
#include <assert.h>
#include <algorithm>
#include <iomanip>
#include <time.h>
#include <math.h>
#include <bitset>

#pragma comment(linker, "/STACK:256000000")

using namespace std;

typedef long long int ll;
typedef long double ld;

const int INF = 1000 * 1000 * 1000 + 21;
const ll LLINF = (1ll << 60) + 5;
const int MOD = 1000 * 1000 * 1000 + 7;


int main(int argc, char **argv) {
    registerGen(argc, argv, 1);

    int to_add = atoi(argv[1]);
    ll min_k = atoll(argv[2]);
    ll max_k = atoll(argv[3]);

    int n, m, q;
    scanf("%d%d%d", &n, &m, &q);
    vector<int> arr(n);
    vector<ll> qq(q);
    for (int i = 0; i < n; ++i) {
        scanf("%d", &arr[i]);
    }
    for (int i = 0; i < q; ++i) {
        scanf("%lld", &qq[i]);
    }

    qq.resize((int)qq.size() + to_add);

    for (int i = q; i < (int)qq.size(); ++i) {
        qq[i] = rnd.next(min_k, max_k);
    }
    q += to_add;
    shuffle(qq.begin(), qq.end());

    printf("%d %d %d\n", n, m, q);
    for (int i = 0; i < n; ++i) {
        printf("%d%c", arr[i], " \n"[i == n - 1]);
    }

    for (int i = 0; i < q; ++i) {
        printf("%lld\n", qq[i]);
    }

    return 0;
}

