#!/usr/local/bin/python3

n, m, q = map(int, input().split())
arr = list(map(int, input().split()))

cnt = [0 for i in range(m)]
for i in range(n):
    cnt[arr[i] - 1] += 1

at = [[] for i in range(n + 1)]
for i in range(m):
    at[cnt[i]].append(i)

def solve(k):
    k -= n + 1;

    cnt_alive = 0;
    alive = [False for i in range(m)]
    for i in range(n + 1):
        cnt_alive += len(at[i])
        for j in range(len(at[i])):
            alive[at[i][j]] = True

        if k < cnt_alive:
            now = 0;
            for j in range(m):
                if alive[j]:
                    now += 1
                if now == k + 1:
                    return j
        else:
            k -= cnt_alive

    return k % m;

for i in range(q):
    k = int(input())
    print(solve(k) + 1)
