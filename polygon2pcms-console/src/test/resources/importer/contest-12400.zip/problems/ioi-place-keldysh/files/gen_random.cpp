#include "testlib.h"
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <string>
#include <string.h>
#include <vector>
#include <stack>
#include <queue>
#include <deque>
#include <set>
#include <map>
#include <assert.h>
#include <algorithm>
#include <iomanip>
#include <time.h>
#include <math.h>
#include <bitset>

#pragma comment(linker, "/STACK:256000000")

using namespace std;

typedef long long int ll;
typedef long double ld;

const int INF = 1000 * 1000 * 1000 + 21;
const ll LLINF = (1ll << 60) + 5;
const int MOD = 1000 * 1000 * 1000 + 7;


int main(int argc, char **argv) {
    registerGen(argc, argv, 1);

    int n = atoi(argv[1]);
    int m = atoi(argv[2]);
    int q = atoi(argv[3]);
    ll max_k = atoll(argv[4]);
    int nm_prob = atoi(argv[5]);

    vector<int> arr(n);
    for (int i = 0; i < n; ++i) {
        arr[i] = rnd.next(1, m);
    }

    printf("%d %d %d\n", n, m, q);
    for (int i = 0; i < n; ++i) {
        printf("%d%c", arr[i], " \n"[i == n - 1]);
    }

    for (int i = 0; i < q; ++i) {
        ll k = n + 1;
        if (rnd.next(1, 100) <= nm_prob) {
            k = rnd.next((ll)n + 1, min((ll)n * m, max_k));
        } else {
            k = rnd.next((ll)n + 1, max_k);
        }

        printf("%lld\n", k);
    }

    return 0;
}

