#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <string>
#include <string.h>
#include <vector>
#include <stack>
#include <queue>
#include <deque>
#include <set>
#include <map>
#include <assert.h>
#include <algorithm>
#include <iomanip>
#include <time.h>
#include <math.h>
#include <bitset>

#pragma comment(linker, "/STACK:256000000")

using namespace std;

typedef long long int ll;
typedef long double ld;

const int INF = 1000 * 1000 * 1000 + 21;
const ll LLINF = (1ll << 60) + 5;
const int MOD = 1000 * 1000 * 1000 + 7;

const int MAX_N = 1000 * 1000 + 228;


int n, m, q;
int cnt[MAX_N];
pair<ll, int> qu[MAX_N];
int ans[MAX_N];
vector<int> at[MAX_N];
int tree[4 * MAX_N];

void upd(int v, int l, int r, int x) {
    if (x < l || r <= x) {
        return;
    } else if (r - l == 1) {
        tree[v] = 1;
    } else {
        int m = (l + r) >> 1;

        upd(2 * v + 1, l, m, x);
        upd(2 * v + 2, m, r, x);

        tree[v] = tree[2 * v + 1] + tree[2 * v + 2];
    }
}

int get_k(int v, int l, int r, int k) {
    if (r - l == 1) {
        return l;
    } else {
        int m = (l + r) >> 1;

        if (tree[2 * v + 1] > k) {
            return get_k(2 * v + 1, l, m, k);
        } else {
            return get_k(2 * v + 2, m, r, k - tree[2 * v + 1]);
        }
    }
}

void solve_all() {
    int ptr = 0;

    ll now_sz = 0;
    for (int i = 0; i <= n; ++i) {
        if (!at[i].empty()) {
            for (int j = 0; j < (int)at[i].size(); ++j) {
                upd(0, 0, m, at[i][j]);
            }
        }

        now_sz += tree[0];
        while (ptr < q && qu[ptr].first < now_sz) {
            ans[qu[ptr].second] = get_k(0, 0, m, qu[ptr].first - now_sz + tree[0]);
            ++ptr;
        }
    }

    assert(tree[0] == m);

    while (ptr < q) {
        ans[qu[ptr].second] = (qu[ptr].first - now_sz) % m;
        ++ptr;
    }
}

int main() {
#ifdef CH_EGOR
    freopen("input.txt", "r", stdin);
    //freopen("output.txt", "w", stdout);
#else
    //freopen("", "r", stdin);
    //freopen("", "w", stdout);
#endif

    scanf("%d%d%d", &n, &m, &q);

    for (int i = 0; i < n; ++i) {
        int x;
        scanf("%d", &x);
        --x;
        ++cnt[x];
    }

    for (int i = 0; i < m; ++i) {
        at[cnt[i]].push_back(i);
    }
    for (int i = 0; i <= n; ++i) {
        sort(at[i].begin(), at[i].end());
    }

    for (int i = 0; i < q; ++i) {
        scanf("%lld", &qu[i].first);
        qu[i].first -= n + 1;
        qu[i].second = i;
    }
    sort(qu, qu + q);

    memset(tree, 0, sizeof(tree));
    solve_all();

    for (int i = 0; i < q; ++i) {
        printf("%d\n", ans[i] + 1);
    }

    return 0;
}

