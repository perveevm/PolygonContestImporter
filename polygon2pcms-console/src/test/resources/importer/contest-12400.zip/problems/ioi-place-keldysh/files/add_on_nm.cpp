#include "testlib.h"
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <string>
#include <string.h>
#include <vector>
#include <stack>
#include <queue>
#include <deque>
#include <set>
#include <map>
#include <assert.h>
#include <algorithm>
#include <iomanip>
#include <time.h>
#include <math.h>
#include <bitset>

#pragma comment(linker, "/STACK:256000000")

using namespace std;

typedef long long int ll;
typedef long double ld;

const int INF = 1000 * 1000 * 1000 + 21;
const ll LLINF = (1ll << 60) + 5;
const int MOD = 1000 * 1000 * 1000 + 7;

const int MAX_N = 1000 * 1000 + 228;

int n, m, q;
int cnt[MAX_N];
int at[MAX_N];
vector<int> add_new;
vector<int> all_correct;
pair<ll, ll> bg_ed[MAX_N];

void solve_all(int min_n, int max_n, ll max_k) {
    ll now = n + 1;

    int cnt_alive = 0;
    for (int i = 0; i <= n; ++i) {
        bg_ed[i].first = now;

        cnt_alive += at[i];
        now += cnt_alive;

        bg_ed[i].second = now - 1;
    }

    assert(cnt_alive == m);

    for (int i = min_n; i <= max_n; ++i) {
        if (bg_ed[i].second <= max_k && bg_ed[i].first <= bg_ed[i].second) {
            all_correct.push_back(i);
            if (at[i]) {
                add_new.push_back(i);
            }
        }
    }
}

ll get_qu(bool on_cr, bool on_new) {
    vector<int>& arr = (on_new ? add_new : all_correct);

    int ptr = rnd.next(0, (int)arr.size() - 1);
    int at_ptr = arr[ptr];

    if (on_cr) {
        if (rnd.next(1, 2) == 1) {
            return bg_ed[at_ptr].first;
        } else {
            return bg_ed[at_ptr].second;
        }
    } else {
        return rnd.next(bg_ed[at_ptr].first, bg_ed[at_ptr].second);
    }
}

int main(int argc, char **argv) {
    registerGen(argc, argv, 1);

    int to_add = atoi(argv[1]);
    int min_n = atoi(argv[2]);
    int max_n = atoi(argv[3]);
    ll max_k = atoll(argv[4]);
    int on_cr = atoi(argv[5]);
    int on_new = atoi(argv[6]);

    scanf("%d%d%d", &n, &m, &q);
    vector<int> arr(n);
    vector<ll> qq(q);
    for (int i = 0; i < n; ++i) {
        scanf("%d", &arr[i]);
        ++cnt[arr[i] - 1];
    }
    for (int i = 0; i < q; ++i) {
        scanf("%lld", &qq[i]);
    }
    for (int i = 0; i < m; ++i) {
        ++at[cnt[i]];
    }

    if (min_n == -1) {
        min_n = 0;
    }
    if (max_n == -1) {
        max_n = n;
    }
    if (max_k == -1) {
        max_k = 1000ll * 1000ll * 1000ll * 1000ll * 1000ll * 1000ll;
    }

    solve_all(min_n, max_n, max_k);

    qq.resize((int)qq.size() + to_add);

    for (int i = q; i < (int)qq.size(); ++i) {
        qq[i] = get_qu(on_cr, on_new);
    }
    q += to_add;
    shuffle(qq.begin(), qq.end());

    printf("%d %d %d\n", n, m, q);
    for (int i = 0; i < n; ++i) {
        printf("%d%c", arr[i], " \n"[i == n - 1]);
    }

    for (int i = 0; i < q; ++i) {
        printf("%lld\n", qq[i]);
    }

    return 0;
}

