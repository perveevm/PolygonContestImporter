#include <bits/stdc++.h>
#include "testlib.h"
#define ff first
#define ss second
#define szof(_x) ((int) (_x).size())

using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
const int INF = 1e9 + 7;
const ll INFL = 1e18 + 123;
const double PI = atan2(0, -1);

const int MAXN = 1000;

int main(int argc, char* argv[]) {
	registerValidation(argc, argv);

	int n = inf.readInt(1, MAXN, "n");
	inf.readSpace();
	int m = inf.readInt(1, MAXN, "m");
	inf.readEoln();

	for (int i = 0; i < n; ++i) {
		inf.readLine(format("[a-z]{%d}", m));
	}

	inf.readEof();

	return 0;
}