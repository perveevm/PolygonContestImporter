#include <bits/stdc++.h>
#include "testlib.h"
#define ff first
#define ss second
#define szof(_x) ((int) (_x).size())

using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
const int INF = 1e9 + 7;
const ll INFL = 1e18 + 123;
const double PI = atan2(0, -1);

int main(int argc, char* argv[]) {
	registerGen(argc, argv, 1);

	int n, m;
	cin >> n >> m;
	vector<vector<char>> field(n, vector<char>(m));
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < m; ++j) {
			cin >> field[i][j];
		}
	}

	for (int i = 0; i < 10; ++i) {
		int h = rnd.next(1, 5);
		int w = rnd.next(1, 5);
		int x = rnd.next(0, n - h);
		int y = rnd.next(0, m - w);
		char c = 'a' + rnd.next(0, 25);
		for (int j = 0; j < h; ++j) {
			for (int k = 0; k < w; ++k) {
				field[x + j][y + k] = c;
			}
		}
	}

	cout << n << " " << m << "\n";
	for (int i = 0; i < n; ++i) {
		for (char c : field[i]) {
			cout << c;
		}
		cout << "\n";
	}

	return 0;
}