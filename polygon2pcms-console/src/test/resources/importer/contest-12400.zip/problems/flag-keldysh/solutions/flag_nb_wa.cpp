// Created by Nikolay Budin

#ifdef LOCAL
#  define _GLIBCXX_DEBUG
#else
#  define cerr __get_ce
#endif
#include <bits/stdc++.h>
#define ff first
#define ss second
#define szof(x) ((int)x.size())

using namespace std;
typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;
typedef unsigned long long ull;
int const INF = (int)1e9 + 1e3;
ll const INFL = (ll)1e18 + 1e6;
#ifdef LOCAL
	mt19937 tw(9450189);
#else
	mt19937 tw(chrono::high_resolution_clock::now().time_since_epoch().count());
#endif
uniform_int_distribution<ll> ll_distr;
ll rnd(ll a, ll b) { return ll_distr(tw) % (b - a + 1) + a; }


void solve() {
	int n, m;
	cin >> n >> m;
	vector<vector<char>> field(n, vector<char>(m));
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < m; ++j) {
			cin >> field[i][j];
		}
	}

	ll ans = 0;

	for (int i = 0; i < n; ++i) {
		for (int j = i + 3; j <= n; j += 3) {
			for (int k = 0; k < m; ++k) {
				for (int l = k + 1; l <= m; ++l) {
					bool ok = true;
					for (int x = 0; x < j - i; ++x) {
						for (int y = 0; y < l - k; ++y) {
							if (x < (j - i) / 3) {
								ok &= field[i + x][k + y] == field[i][k];
							} else if (x < (j - i) / 3 * 2) {
								ok &= field[i + x][k + y] == field[i + (j - i) / 3][k];
							} else {
								ok &= field[i + x][k + y] == field[i + (j - i) / 3 * 2][k];
							}
						}
					}
					if (ok) {
						++ans;
					} else {
						break;
					}
				}
			}
		}
	}

	cout << ans << "\n";
}


int main() {
#ifdef LOCAL
	auto start_time = clock();
	cerr << setprecision(3) << fixed;
#endif
	cout << setprecision(15) << fixed;
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int test_count = 1;
	// cin >> test_count;
	for (int test = 1; test <= test_count; ++test) {
		solve();
	}
	
#ifdef LOCAL
	auto end_time = clock();
	cerr << "Execution time: " << (end_time - start_time) * (int)1e3 / CLOCKS_PER_SEC << " ms\n";
#endif
}
