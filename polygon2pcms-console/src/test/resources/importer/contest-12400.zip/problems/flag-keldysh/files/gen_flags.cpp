#include <bits/stdc++.h>
#include "testlib.h"
#define ff first
#define ss second
#define szof(_x) ((int) (_x).size())

using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
const int INF = 1e9 + 7;
const ll INFL = 1e18 + 123;
const double PI = atan2(0, -1);

int main(int argc, char* argv[]) {
	registerGen(argc, argv, 1);

	int n = atoi(argv[1]);
	int m = atoi(argv[2]);
	int k = atoi(argv[3]);

	vector<vector<char>> field(n, vector<char>(m, 'a' + rnd.next(0, 25)));

	vector<pair<pair<pii, pii>, char>> rects;
	rects.push_back({{{0, n}, {0, m}}, 'a' + rnd.next(0, 25)});
	for (int i = 0; i < k; ++i) {
		int x1, x2, y1, y2;
		char c1, c2, c3;
		while (true) {
			c1 = 'a' + rnd.next(0, 25);
			c2 = 'a' + rnd.next(0, 25);
			c3 = 'a' + rnd.next(0, 25);
			if (c1 != c2 && c2 != c3) {
				break;
			}
		}
		while (true) {
			x1 = rnd.next(0, n - 1);
			x2 = rnd.next(0, n - 1);
			y1 = rnd.next(0, m - 1);
			y2 = rnd.next(0, m - 1);
			if (x1 <= x2 && y1 <= y2 && (x2 - x1 + 1) % 3 == 0) {
				break;
			}
		}
		rects.push_back({{{x1, x1 + (x2 - x1 + 1) / 3}, {y1, y2 + 1}}, c1});
		rects.push_back({{{x1 + (x2 - x1 + 1) / 3, x1 + (x2 - x1 + 1) / 3 * 2}, {y1, y2 + 1}}, c2});
		rects.push_back({{{x1 + (x2 - x1 + 1) / 3 * 2, x2 + 1}, {y1, y2 + 1}}, c3});
	}

	vector<pii> actions;
	for (int i = 0; i < szof(rects); ++i) {
		auto r = rects[i];
		actions.push_back({r.ff.ss.ff, i});
		actions.push_back({r.ff.ss.ss, i});
	}

	int cnt = 0;
	sort(actions.begin(), actions.end());

	int bpv = 1;
	while (bpv < n) {
		bpv *= 2;
	}

	vector<set<pair<int, char>>> segtree(bpv * 2);

	function<void(int, int, int, int, int, pair<int, char>)> segtree_add = [&](int v, int vl, int vr, int l, int r, pair<int, char> val) {
		if (vr <= l || r <= vl) {
			return;
		}
		if (l <= vl && vr <= r) {
			segtree[v].insert(val);
			return;
		}
		int vm = (vl + vr) / 2;
		segtree_add(v * 2, vl, vm, l, r, val);
		segtree_add(v * 2 + 1, vm, vr, l, r, val);
	};

	function<void(int, int, int, int, int, pair<int, char>)> segtree_rem = [&](int v, int vl, int vr, int l, int r, pair<int, char> val) {
		if (vr <= l || r <= vl) {
			return;
		}
		if (l <= vl && vr <= r) {
			segtree[v].erase(val);
			return;
		}
		int vm = (vl + vr) / 2;
		segtree_rem(v * 2, vl, vm, l, r, val);
		segtree_rem(v * 2 + 1, vm, vr, l, r, val);
	};

	auto segtree_get = [&](int pos) {
		pos += bpv;
		pair<int, char> ret = {-INF, '?'};
		while (pos) {
			if (szof(segtree[pos])) {
				ret = max(ret, *--segtree[pos].end());
			}
			pos /= 2;
		}
		return ret;
	};

	vector<bool> type(szof(rects));
	for (int i = 0; i < m; ++i) {
		while (cnt < szof(actions) && actions[cnt].ff == i) {
			int ind = actions[cnt].ss;
			++cnt;
			if (!type[ind]) {
				segtree_add(1, 0, bpv, rects[ind].ff.ff.ff, rects[ind].ff.ff.ss, {ind, rects[ind].ss});
			} else {
				segtree_rem(1, 0, bpv, rects[ind].ff.ff.ff, rects[ind].ff.ff.ss, {ind, rects[ind].ss});
			}
			type[ind] = 1 ^ type[ind];
		}

		for (int j = 0; j < n; ++j) {
			field[j][i] = segtree_get(j).ss;
		}
	}

	cout << n << " " << m << "\n";

	for (auto& v : field) {
		for (auto c : v) {
			cout << c;
		}
		cout << "\n";
	}

	return 0;
}