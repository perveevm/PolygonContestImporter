import java.io.OutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.BufferedWriter;
import java.io.Writer;
import java.io.OutputStreamWriter;
import java.io.IOException;
import java.io.InputStream;

/**
 * Built using CHelper plug-in
 * Actual solution is at the top
 *
 * @author ch_egor
 */
public class Main {
    public static void main(String[] args) {
        InputStream inputStream = System.in;
        OutputStream outputStream = System.out;
        InputReader in = new InputReader(inputStream);
        OutputWriter out = new OutputWriter(outputStream);
        C solver = new C();
        solver.solve(1, in, out);
        out.close();
    }

    static class C {
        public void solve(int testNumber, InputReader in, OutputWriter out) {
            int n = in.nextInt();
            int m = in.nextInt();

            char[][] arr = new char[n][];
            int[][] hash = new int[n][];
            for (int i = 0; i < n; ++i) {
                String st = in.nextString();

                arr[i] = new char[m];
                hash[i] = new int[m];
                for (int j = 0; j < m; ++j) {
                    arr[i][j] = st.charAt(j);
                    hash[i][j] = -1;
                }
            }

            for (int i = 0; i < m; ++i) {
                for (int j = 0; j < n; ++j) {
                    if (j != 0 && arr[j][i] != arr[j - 1][i]) {
                        int k = j;
                        while (k < n && arr[k][i] == arr[j][i]) {
                            ++k;
                        }
                        if (k + (k - j) <= n && j - (k - j) >= 0) {
                            boolean ok = true;
                            for (int q = 0; q < k - j; ++q) {
                                if (arr[j - 1 - q][i] != arr[j - 1][i] || arr[k + q][i] != arr[k][i]) {
                                    ok = false;
                                    break;
                                }
                            }

                            if (ok) {
                                hash[j][i] = (((arr[j - 1][i] - 'a') * 26 + arr[j][i] - 'a') * 26 + arr[k][i] - 'a') * (n + m) + (k - j);
                            }
                        }
                    }
                }
            }

            long answer = 0;
            for (int i = 0; i < n; ++i) {
                int from = 0;
                for (int j = 0; j <= m; ++j) {
                    if (j == m || hash[i][j] != hash[i][from]) {
                        if (hash[i][from] != -1) {
                            answer += (long) (j - from) * (j - from + 1) / 2;
                        }
                        from = j;
                    }
                }
            }

            out.println(answer);
        }

    }

    static class OutputWriter {
        private final PrintWriter writer;

        public OutputWriter(OutputStream outputStream) {
            writer = new PrintWriter(new BufferedWriter(new OutputStreamWriter(outputStream)));
        }

        public OutputWriter(Writer writer) {
            this.writer = new PrintWriter(writer);
        }

        public void close() {
            writer.close();
        }

        public void println(long i) {
            writer.println(i);
        }

    }

    static class InputReader {
        private InputStream stream;
        private byte[] buf = new byte[1024];
        private int curChar;
        private int numChars;
        private InputReader.SpaceCharFilter filter;

        public InputReader(InputStream stream) {
            this.stream = stream;
        }

        public int read() {
            if (numChars == -1) {
                throw new UnknownError();
            }
            if (curChar >= numChars) {
                curChar = 0;
                try {
                    numChars = stream.read(buf);
                } catch (IOException e) {
                    throw new UnknownError();
                }
                if (numChars <= 0) {
                    return -1;
                }
            }
            return buf[curChar++];
        }

        public int nextInt() {
            int c = read();
            while (isSpaceChar(c)) {
                c = read();
            }
            int sgn = 1;
            if (c == '-') {
                sgn = -1;
                c = read();
            }
            int res = 0;
            do {
                if (c < '0' || c > '9') {
                    throw new UnknownError();
                }
                res *= 10;
                res += c - '0';
                c = read();
            } while (!isSpaceChar(c));
            return res * sgn;
        }

        public String nextString() {
            int c = read();
            while (isSpaceChar(c)) {
                c = read();
            }
            StringBuilder res = new StringBuilder();
            do {
                if (Character.isValidCodePoint(c)) {
                    res.appendCodePoint(c);
                }
                c = read();
            } while (!isSpaceChar(c));
            return res.toString();
        }

        public boolean isSpaceChar(int c) {
            if (filter != null) {
                return filter.isSpaceChar(c);
            }
            return isWhitespace(c);
        }

        public static boolean isWhitespace(int c) {
            return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == -1;
        }

        public interface SpaceCharFilter {
            public boolean isSpaceChar(int ch);

        }

    }
}

