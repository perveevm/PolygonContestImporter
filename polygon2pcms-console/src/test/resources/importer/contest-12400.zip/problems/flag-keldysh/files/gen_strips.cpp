#include <bits/stdc++.h>
#include "testlib.h"
#define ff first
#define ss second
#define szof(_x) ((int) (_x).size())

using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
const int INF = 1e9 + 7;
const ll INFL = 1e18 + 123;
const double PI = atan2(0, -1);

int main(int argc, char* argv[]) {
	registerGen(argc, argv, 1);

	int n = atoi(argv[1]);
	int m = atoi(argv[2]);
	int k = atoi(argv[3]);
	assert(1 <= k && k <= m);

	vector<vector<char>> field(n, vector<char>(m, 'a' + rnd.next(0, 25)));

	for (int i = 0; i < n; ++i) {
		vector<int> all(m - 1);
		iota(all.begin(), all.end(), 0);
		shuffle(all.begin(), all.end());
		all.resize(k - 1);
		int cnt = 0;
		sort(all.begin(), all.end());
		char c = 'a' + i % 26;
		for (int j = 0; j < m; ++j) {
			field[i][j] = c;
			if (cnt < szof(all) && all[cnt] == j) {
				c = 'a' + rnd.next(0, 25);
				++cnt;
			}
		}
	}

	cout << n << " " << m << "\n";

	for (auto& v : field) {
		for (auto c : v) {
			cout << c;
		}
		cout << "\n";
	}

	return 0;
}