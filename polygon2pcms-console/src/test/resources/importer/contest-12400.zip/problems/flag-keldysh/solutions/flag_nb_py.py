import sys

def solve():
	n, m = map(int, input().split())

	field = [[0] * m for _ in range(n)]

	for i in range(n):
		s = input()
		for j in range(m):
			field[i][j] = s[j]

	res = [[0] * m for _ in range(n)]

	for i in range(n):
		for j in range(m):
			if i > 0 and field[i][j] != field[i - 1][j]:
				ok = True
				l = 0
				while i + l < n and field[i + l][j] == field[i][j]:
					l += 1

				if i + l * 2 > n or i < l:
					continue

				for k in range(l):
					if field[i - 1 - k][j] != field[i - 1][j] or field[i + l + k][j] != field[i + l][j]:
						ok = False
						break

				ok &= field[i - 1][j] != field[i][j] and field[i][j] != field[i + l][j]

				if ok:
					res[i][j] = (field[i - 1][j], field[i][j], field[i + l][j], l)

	ans = 0

	for i in range(n):
		for j in range(m):
			if res[i][j] == 0 or (j > 0 and res[i][j] == res[i][j - 1]):
				continue

			l = 0
			while j + l < m and res[i][j + l] == res[i][j]:
				l += 1

			ans += l * (l + 1) // 2

	print(ans)

solve()