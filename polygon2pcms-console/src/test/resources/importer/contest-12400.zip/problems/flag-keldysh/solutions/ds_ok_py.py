#!/usr/bin/python3
# Dmitry _kun_ Sayutin (2019)

n, m = map(int, input().split())

field = [input() for i in range(n)]

ans = 0
for line in range(1, n):
    cur_type = -1
    streak = 0

    for col in range(m):
        tp = -1

        if field[line - 1][col] != field[line][col]:
            height = 1
            
            while line + height != n and field[line + height][col] == field[line][col]:
                height += 1

            if line + 2 * height <= n and line >= height:
                c0, c1, c2 = field[line - 1][col], field[line][col], field[line + height][col]

                ptr = line - 1
                while ptr != line - height - 1 and field[ptr][col] == c0:
                    ptr -= 1

                if ptr == line - height - 1:
                    ptr = line + height
                    while ptr != line + 2 * height and field[ptr][col] == c2:
                        ptr += 1

                    if ptr == line + 2 * height:
                        tp = (height, c0, c1, c2)


        if tp == -1:
            cur_type = -1
            streak = 0
        elif tp == cur_type:
            streak += 1
            ans += streak
        else:
            cur_type = tp
            streak = 1
            ans += 1

print(ans)
