// Created by Nikolay Budin

#ifdef LOCAL
#  define _GLIBCXX_DEBUG
#else
#  define cerr __get_ce
#endif
#include <bits/stdc++.h>
#define ff first
#define ss second
#define szof(x) ((int)x.size())

using namespace std;
typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;
typedef unsigned long long ull;
int const INF = (int)1e9 + 1e3;
ll const INFL = (ll)1e18 + 1e6;
#ifdef LOCAL
	mt19937 tw(9450189);
#else
	mt19937 tw(chrono::high_resolution_clock::now().time_since_epoch().count());
#endif
uniform_int_distribution<ll> ll_distr;
ll rnd(ll a, ll b) { return ll_distr(tw) % (b - a + 1) + a; }


void solve() {
	int n, m;
	cin >> n >> m;
	vector<vector<char>> field(n, vector<char>(m));
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < m; ++j) {
			cin >> field[i][j];
		}
	}

	int ans = 0;

	for (int x1 = 0; x1 < n; ++x1) {
		for (int x2 = x1 + 1; x2 <= n; ++x2) {
			for (int y1 = 0; y1 < m; ++y1) {
				for (int y2 = y1 + 1; y2 <= m; ++y2) {
					if ((x2 - x1) % 3) {
						continue;
					}
					int q = (x2 - x1) / 3;
					bool ok = true;
					for (int i = 0; i < x2 - x1; ++i) {
						for (int j = 0; j < y2 - y1; ++j) {
							if (field[x1 + i][y1 + j] != field[x1 + i / q * q][y1]) {
								ok = false;
							}
						}
					}
					ok &= (field[x1 + q][y1] != field[x1][y1]);
					ok &= (field[x1 + q * 2][y1] != field[x1 + q][y1]);
					if (ok) {
						++ans;
					}
				}
			}
		}
	}

	cout << ans << "\n";
}


int main() {
#ifdef LOCAL
	auto start_time = clock();
	cerr << setprecision(3) << fixed;
#endif
	cout << setprecision(15) << fixed;
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int test_count = 1;
	// cin >> test_count;
	for (int test = 1; test <= test_count; ++test) {
		solve();
	}
	
#ifdef LOCAL
	auto end_time = clock();
	cerr << "Execution time: " << (end_time - start_time) * (int)1e3 / CLOCKS_PER_SEC << " ms\n";
#endif
}
