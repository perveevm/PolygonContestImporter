// Created by Nikolay Budin

#ifdef LOCAL
#  define _GLIBCXX_DEBUG
#else
#  define cerr __get_ce
#endif
#include <bits/stdc++.h>
#define ff first
#define ss second
#define szof(x) ((int)x.size())

using namespace std;
typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;
typedef unsigned long long ull;
int const INF = (int)1e9 + 1e3;
ll const INFL = (ll)1e18 + 1e6;
#ifdef LOCAL
	mt19937 tw(9450189);
#else
	mt19937 tw(chrono::high_resolution_clock::now().time_since_epoch().count());
#endif
uniform_int_distribution<ll> ll_distr;
ll rnd(ll a, ll b) { return ll_distr(tw) % (b - a + 1) + a; }


void solve() {
	int n, m;
	cin >> n >> m;
	vector<vector<char>> field(n, vector<char>(m));

	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < m; ++j) {
			cin >> field[i][j];
		}
	}

	int ans = 0;

	for (int i = 0; i < n; ++i) {
		for (int j = i + 3; j <= n; j += 3) {
			int q = (j - i) / 3;
			for (int k = 0; k < m; ++k) {
				bool ok = true;
				for (int l = 0; l < j - i; ++l) {
					if (field[i + l][k] != field[i + l / q * q][k]) {
						ok = false;
					}
				}
				ok &= field[i][k] != field[i + q][k];
				ok &= field[i + q * 2][k] != field[i + q][k];
				if (ok) {
					ans++;
					for (int l = k + 1; l < m; ++l) {
						bool flag = true;
						for (int x = i; x < j; ++x) {
							if (field[x][l] != field[x][k]) {
								flag = false;
							}
						}
						if (!flag) {
							break;
						}
						++ans;
					}
				}
			}
		}
	}
	cout << ans << "\n";
}


int main() {
#ifdef LOCAL
	auto start_time = clock();
	cerr << setprecision(3) << fixed;
#endif
	cout << setprecision(15) << fixed;
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int test_count = 1;
	// cin >> test_count;
	for (int test = 1; test <= test_count; ++test) {
		solve();
	}
	
#ifdef LOCAL
	auto end_time = clock();
	cerr << "Execution time: " << (end_time - start_time) * (int)1e3 / CLOCKS_PER_SEC << " ms\n";
#endif
}
