#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <string>
#include <string.h>
#include <vector>
#include <stack>
#include <queue>
#include <deque>
#include <set>
#include <map>
#include <assert.h>
#include <algorithm>
#include <iomanip>
#include <time.h>
#include <math.h>
#include <bitset>

#pragma comment(linker, "/STACK:256000000")

using namespace std;

typedef long long int ll;
typedef long double ld;

const int INF = 1000 * 1000 * 1000 + 21;
const ll LLINF = (1ll << 60) + 5;
const int MOD = 1000 * 1000 * 1000 + 7;

const int MAX_N = 100 * 1000 + 228;

struct rec {
    int x1;
    int y1;
    int x2;
    int y2;
};

int n;
rec arr[MAX_N];

struct cmp_x1 {
    bool operator()(int a, int b) const {
        return (arr[a].x1 < arr[b].x1) || (arr[a].x1 == arr[b].x1 && a < b);
    }
};

struct cmp_x2 {
    bool operator()(int a, int b) const {
        return (arr[a].x2 < arr[b].x2) || (arr[a].x2 == arr[b].x2 && a < b);
    }
};

struct cmp_y1 {
    bool operator()(int a, int b) const {
        return (arr[a].y1 < arr[b].y1) || (arr[a].y1 == arr[b].y1 && a < b);
    }
};

struct cmp_y2 {
    bool operator()(int a, int b) const {
        return (arr[a].y2 < arr[b].y2) || (arr[a].y2 == arr[b].y2 && a < b);
    }
};

void no() {
    printf("NO\n");
    exit(0);
}

struct tree {
    vector<int> tr;
    vector<int> mod;
    vector<int> coord;

    void build(vector<int>& _coord) {
        coord = std::move(_coord);
        coord.resize(unique(coord.begin(), coord.end()) - coord.begin());

        tr.resize(4 * (int)coord.size());
        mod.resize(4 * (int)coord.size());
        memset(&tr[0], 0, sizeof(int) * (int)tr.size());
        memset(&mod[0], 0, sizeof(int) * (int)mod.size());
    }

    int get_cord(int x) {
        return lower_bound(coord.begin(), coord.end(), x) - coord.begin();
    }

    int get_real(int x) {
        return coord[x];
    }

    void add_v(int v, int md) {
        tr[v] += md;
        mod[v] += md;
    }

    void push(int v) {
        add_v(2 * v + 1, mod[v]);
        add_v(2 * v + 2, mod[v]);
        mod[v] = 0;
    }

    void add_range(int v, int l, int r, int x, int y, int md) {
        if (r <= x || y <= l) {
            return;
        } else if (x <= l && r <= y) {
            add_v(v, md);
        } else {
            push(v);
            int m = (l + r) >> 1;

            add_range(2 * v + 1, l, m, x, y, md);
            add_range(2 * v + 2, m, r, x, y, md);

            tr[v] = min(tr[2 * v + 1], tr[2 * v + 2]);
        }
    }

    void add_range(int l, int r, int md) {
        if (l >= r) {
            return;
        }

        l = get_cord(l);
        r = get_cord(r);

        add_range(0, 0, (int)coord.size(), l, r, md);
    }

    int find_cut(int l, int r) {
        l = get_cord(l);
        r = get_cord(r);

        return find_cut(0, 0, (int)coord.size(), l, r);
    }

    int find_cut(int v, int l, int r, int x, int y) {
        if (r <= x || y <= l) {
            return -1;
        } else if (x <= l && r <= y) {
            if (tr[v] != 0) {
                return -1;
            }

            if (r - l == 1) {
                return l;
            }

            push(v);
            int m = (l + r) >> 1;

            if (tr[2 * v + 1] == 0) {
                return find_cut(2 * v + 1, l, m, x, y);
            } else {
                return find_cut(2 * v + 2, m, r, x, y);
            }
        } else {
            push(v);
            int m = (l + r) >> 1;

            int ret = find_cut(2 * v + 1, l, m, x, y);
            if (ret == -1) {
                ret = find_cut(2 * v + 2, m, r, x, y);
            }

            return ret;
        }
    }
};

vector<int> coord_x1;
vector<int> coord_y1;
vector<int> coord_x2;
vector<int> coord_y2;

int cnt_prob = 1;
struct prob {
    prob* probs;

    set<int, cmp_x1> st_x1;
    set<int, cmp_x2> st_x2;
    set<int, cmp_y1> st_y1;
    set<int, cmp_y2> st_y2;

    tree tree_x;
    tree tree_y;

    void rebuild_trees() {
        coord_x1.clear();
        coord_x2.clear();
        coord_y1.clear();
        coord_y2.clear();
        vector<int> coord_x;
        vector<int> coord_y;

        for (int ptr : st_x1) {
            coord_x1.push_back(arr[ptr].x1 + 1);
        }
        for (int ptr : st_x2) {
            coord_x2.push_back(arr[ptr].x2);
        }
        for (int ptr : st_y1) {
            coord_y1.push_back(arr[ptr].y1 + 1);
        }
        for (int ptr : st_y2) {
            coord_y2.push_back(arr[ptr].y2);
        }

        coord_x.resize((int)coord_x1.size() + (int)coord_x2.size());
        coord_y.resize((int)coord_y1.size() + (int)coord_y2.size());
        merge(coord_x1.begin(), coord_x1.end(), coord_x2.begin(), coord_x2.end(), coord_x.begin());
        merge(coord_y1.begin(), coord_y1.end(), coord_y2.begin(), coord_y2.end(), coord_y.begin());

        tree_x.build(coord_x);
        tree_y.build(coord_y);

        for (int ptr : st_x1) {
            tree_x.add_range(arr[ptr].x1 + 1, arr[ptr].x2, 1);
        }
        for (int ptr : st_y1) {
            tree_y.add_range(arr[ptr].y1 + 1, arr[ptr].y2, 1);
        }
    }

    void add_req(int x) {
        st_x1.insert(x);
        st_x2.insert(x);
        st_y1.insert(x);
        st_y2.insert(x);
    }

    bool full_cut() {
        return (int)st_x1.size() <= 3;
    }

    void cut_x(int x) {
        prob& new_porb = probs[cnt_prob++];

        for (auto it1 = st_x1.begin(), it2 = --st_x2.end(); it1 != st_x1.end(); ++it1, --it2) {
            if (arr[*it1].x1 >= x) {
                for (auto cur_it = st_x1.begin(); cur_it != it1; cur_it = st_x1.erase(cur_it)) {
                    st_x2.erase(*cur_it);
                    st_y1.erase(*cur_it);
                    st_y2.erase(*cur_it);
                    tree_x.add_range(arr[*cur_it].x1 + 1, arr[*cur_it].x2, -1);
                    tree_y.add_range(arr[*cur_it].y1 + 1, arr[*cur_it].y2, -1);
                    new_porb.add_req(*cur_it);
                }

                new_porb.rebuild_trees();
                return;
            }
            if (arr[*it2].x2 <= x) {
                for (auto cur_it = ++it2; cur_it != st_x2.end(); cur_it = st_x2.erase(cur_it)) {
                    st_x1.erase(*cur_it);
                    st_y1.erase(*cur_it);
                    st_y2.erase(*cur_it);
                    tree_x.add_range(arr[*cur_it].x1 + 1, arr[*cur_it].x2, -1);
                    tree_y.add_range(arr[*cur_it].y1 + 1, arr[*cur_it].y2, -1);
                    new_porb.add_req(*cur_it);
                }

                new_porb.rebuild_trees();
                return;
            }
        }

        assert(false);
    }

    void cut_y(int y) {
        prob& new_porb = probs[cnt_prob++];

        for (auto it1 = st_y1.begin(), it2 = --st_y2.end(); it1 != st_y1.end(); ++it1, --it2) {
            if (arr[*it1].y1 >= y) {
                for (auto cur_it = st_y1.begin(); cur_it != it1; cur_it = st_y1.erase(cur_it)) {
                    st_x1.erase(*cur_it);
                    st_x2.erase(*cur_it);
                    st_y2.erase(*cur_it);
                    tree_x.add_range(arr[*cur_it].x1 + 1, arr[*cur_it].x2, -1);
                    tree_y.add_range(arr[*cur_it].y1 + 1, arr[*cur_it].y2, -1);
                    new_porb.add_req(*cur_it);
                }

                new_porb.rebuild_trees();
                return;
            }
            if (arr[*it2].y2 <= y) {
                for (auto cur_it = ++it2; cur_it != st_y2.end(); cur_it = st_y2.erase(cur_it)) {
                    st_x1.erase(*cur_it);
                    st_x2.erase(*cur_it);
                    st_y1.erase(*cur_it);
                    tree_x.add_range(arr[*cur_it].x1 + 1, arr[*cur_it].x2, -1);
                    tree_y.add_range(arr[*cur_it].y1 + 1, arr[*cur_it].y2, -1);
                    new_porb.add_req(*cur_it);
                }

                new_porb.rebuild_trees();
                return;
            }
        }

        assert(false);
    }

    bool cut() {
        int cut = tree_x.find_cut(arr[*st_x1.begin()].x1 + 1, arr[*--st_x2.end()].x2);

        if (cut == -1) {
            int cut = tree_y.find_cut(arr[*st_y1.begin()].y1 + 1, arr[*--st_y2.end()].y2);
            if (cut == -1) {
                return false;
            } else {
                cut_y(tree_y.get_real(cut));
            }
        } else {
            cut_x(tree_x.get_real(cut));
        }

        return true;
    }
};

prob probs[2 * MAX_N];

int main() {
#ifdef CH_EGOR
    freopen("input.txt", "r", stdin);
    //freopen("output.txt", "w", stdout);
#else
    //freopen("", "r", stdin);
    //freopen("", "w", stdout);
#endif

    for (int i = 0; i < 2 * MAX_N; ++i) {
        probs[i].probs = probs;
    }

    scanf("%d", &n);

    for (int i = 0; i < n; ++i) {
        scanf("%d%d%d%d", &arr[i].x1, &arr[i].y1, &arr[i].x2, &arr[i].y2);
    }

    for (int i = 0; i < n; ++i) {
        probs[0].add_req(i);
    }
    probs[0].rebuild_trees();

    cnt_prob = 1;
    for (int i = 0; i < cnt_prob; ++i) {
        while (!probs[i].full_cut()) {
            if (!probs[i].cut()) {
                no();
            }
        }
    }

    printf("YES\n");

    return 0;
}

