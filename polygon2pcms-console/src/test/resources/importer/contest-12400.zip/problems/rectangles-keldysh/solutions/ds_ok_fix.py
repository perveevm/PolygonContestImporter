#!/usr/bin/python3
# Dmitry _kun_ Sayutin (2019)

import sys

def no():
    print("NO")
    sys.exit(0)
    
n = int(input())

X1 = [None for i in range(n)]
X2 = [None for i in range(n)]
Y1 = [None for i in range(n)]
Y2 = [None for i in range(n)]

def run(indset):
    s = [None for i in range(4)]
    
    s[0] = [elem for elem in indset]
    s[1] = [elem for elem in indset]
    s[2] = [elem for elem in indset]
    s[3] = [elem for elem in indset]

    s[0].sort(key=lambda i: X1[i])
    s[1].sort(key=lambda i: -X2[i])
    
    s[2].sort(key=lambda i: Y1[i])
    s[3].sort(key=lambda i: -Y2[i])

    dead = set()

    nxt = [[i + 1 for i in range(len(indset) + 1)] for z in range(4)]

    # head of list
    nxt[0][len(indset)] = nxt[1][len(indset)] = nxt[2][len(indset)] = nxt[3][len(indset)] = 0
    
    ptr = None    
    def next(num):
        p = ptr[num]

        while s[num][nxt[num][p]] in dead:
            nxt[num][p] = nxt[num][nxt[num][p]]

        ptr[num] = nxt[num][p]
        return s[num][ptr[num]]

    alive = len(indset)
    while alive >= 2:
        ptr = [len(indset) for i in range(4)]

        take = [[] for i in range(4)]

        a = next(0)
        b = next(1)
        c = next(2)
        d = next(3)

        take[0].append(a)
        take[1].append(b)
        take[2].append(c)
        take[3].append(d)

        max_x2 = X2[a]
        min_x1 = X1[b]
        max_y2 = Y2[c]
        min_y1 = Y1[d]

        did = False
        
        for x in range(alive - 1):
            a = next(0)
            b = next(1)
            c = next(2)
            d = next(3)

            tk = None
            if max_x2 <= X1[a]:
                tk = take[0]
                
            if X2[b] <= min_x1:
                tk = take[1]
                
            if max_y2 <= Y1[c]:
                tk = take[2]
                
            if Y2[d] <= min_y1:
                tk = take[3]

            if tk != None:
                run(tk)
                for elem in tk:
                    dead.add(elem)
                    
                alive -= len(tk)
                did = True
                break
            
            take[0].append(a)
            take[1].append(b)
            take[2].append(c)
            take[3].append(d)

            max_x2 = max(max_x2, X2[a])
            min_x1 = min(min_x1, X1[b])
            max_y2 = max(max_y2, Y2[c])
            min_y1 = min(min_y1, Y1[d])

        if not did:
            break

    if alive > 1:
        no()

for i in range(n):
    X1[i], Y1[i], X2[i], Y2[i] = map(int, input().split())

run(list(range(n)))
print("YES")
