#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <string>
#include <string.h>
#include <vector>
#include <stack>
#include <queue>
#include <deque>
#include <set>
#include <map>
#include <assert.h>
#include <algorithm>
#include <iomanip>
#include <time.h>
#include <math.h>
#include <bitset>

#pragma comment(linker, "/STACK:256000000")

using namespace std;

typedef long long int ll;
typedef long double ld;

const int INF = 1000 * 1000 * 1000 + 21;
const ll LLINF = (1ll << 60) + 5;
const int MOD = 1000 * 1000 * 1000 + 7;

const int MAX_N = 100 * 1000 + 228;

struct rec {
    int x1;
    int y1;
    int x2;
    int y2;
};

struct seg {
    int l;
    int r;
};

int n;
rec arr[MAX_N];
seg seg_x[MAX_N];
seg seg_y[MAX_N];

struct cmp_x {
    bool operator()(int a, int b) const {
        return (arr[a].x1 < arr[b].x1) || (arr[a].x1 == arr[b].x1 && a < b);
    }
};

struct cmp_y {
    bool operator()(int a, int b) const {
        return (arr[a].y1 < arr[b].y1) || (arr[a].y1 == arr[b].y1 && a < b);
    }
};

void no() {
    printf("NO\n");
    exit(0);
}

struct tree {
    vector<int> tr;
    vector<int> mod;
    vector<int> coord;

    void build(vector<int>& _coord) {
        coord = std::move(_coord);
        sort(coord.begin(), coord.end());
        coord.resize(unique(coord.begin(), coord.end()) - coord.begin());

        tr.resize(4 * (int)coord.size());
        mod.resize(4 * (int)coord.size());
        memset(&tr[0], 0, sizeof(int) * (int)tr.size());
        memset(&mod[0], 0, sizeof(int) * (int)mod.size());
    }

    int get_cord(int x) {
        return lower_bound(coord.begin(), coord.end(), x) - coord.begin();
    }

    int get_real(int x) {
        return coord[x];
    }

    void add_v(int v, int md) {
        tr[v] += md;
        mod[v] += md;
    }

    void push(int v) {
        add_v(2 * v + 1, mod[v]);
        add_v(2 * v + 2, mod[v]);
        mod[v] = 0;
    }

    void add_range(int v, int l, int r, int x, int y, int md) {
        if (r <= x || y <= l) {
            return;
        } else if (x <= l && r <= y) {
            add_v(v, md);
        } else {
            push(v);
            int m = (l + r) >> 1;

            add_range(2 * v + 1, l, m, x, y, md);
            add_range(2 * v + 2, m, r, x, y, md);

            tr[v] = min(tr[2 * v + 1], tr[2 * v + 2]);
        }
    }

    void add_range(int l, int r, int md) {
        if (l >= r) {
            return;
        }

        l = get_cord(l);
        r = get_cord(r);

        add_range(0, 0, (int)coord.size(), l, r, md);
    }

    int find_cut(int l, int r) {
        l = get_cord(l);
        r = get_cord(r);

        return find_cut(0, 0, (int)coord.size(), l, r);
    }

    int find_cut(int v, int l, int r, int x, int y) {
        if (r <= x || y <= l) {
            return -1;
        } else if (x <= l && r <= y) {
            if (tr[v] != 0) {
                return -1;
            }

            if (r - l == 1) {
                return l;
            }

            push(v);
            int m = (l + r) >> 1;

            if (tr[2 * v + 1] == 0) {
                return find_cut(2 * v + 1, l, m, x, y);
            } else {
                return find_cut(2 * v + 2, m, r, x, y);
            }
        } else {
            push(v);
            int m = (l + r) >> 1;

            int ret = find_cut(2 * v + 1, l, m, x, y);
            if (ret == -1) {
                ret = find_cut(2 * v + 2, m, r, x, y);
            }

            return ret;
        }
    }
};

int cnt_prob = 1;
struct prob {
    prob* probs;

    set<int, cmp_x> st_x;
    set<int, cmp_y> st_y;

    tree tree_x;
    tree tree_y;

    void rebuild_trees() {
        vector<int> coord_x;
        vector<int> coord_y;

        for (int ptr : st_x) {
            coord_x.push_back(arr[ptr].x1 + 1);
            coord_x.push_back(arr[ptr].x2);
        }

        for (int ptr : st_y) {
            coord_y.push_back(arr[ptr].y1 + 1);
            coord_y.push_back(arr[ptr].y2);
        }

        tree_x.build(coord_x);
        tree_y.build(coord_y);

        for (int ptr : st_x) {
            tree_x.add_range(arr[ptr].x1 + 1, arr[ptr].x2, 1);
            tree_y.add_range(arr[ptr].y1 + 1, arr[ptr].y2, 1);
        }
    }

    void add_req(int x) {
        st_x.insert(x);
        st_y.insert(x);
    }

    bool full_cut() {
        return (int)st_x.size() <= 3;
    }

    template<typename cmp_fr, typename cmp_sc>
    void do_cut(int x, set<int, cmp_fr>& fr, set<int, cmp_sc>& sc, seg segs[MAX_N]) {
        prob& new_porb = probs[cnt_prob++];

        for (auto it1 = fr.begin(), it2 = --fr.end(); it1 != fr.end(); ++it1, --it2) {
            if (segs[*it1].l >= x) {
                for (auto cur_it = fr.begin(); cur_it != it1; cur_it = fr.erase(cur_it)) {
                    sc.erase(*cur_it);
                    tree_x.add_range(arr[*cur_it].x1 + 1, arr[*cur_it].x2, -1);
                    tree_y.add_range(arr[*cur_it].y1 + 1, arr[*cur_it].y2, -1);
                    new_porb.add_req(*cur_it);
                }

                new_porb.rebuild_trees();
                return;
            }
            if (segs[*it2].r <= x) {
                for (auto cur_it = ++it2; cur_it != fr.end(); cur_it = fr.erase(cur_it)) {
                    sc.erase(*cur_it);
                    tree_x.add_range(arr[*cur_it].x1 + 1, arr[*cur_it].x2, -1);
                    tree_y.add_range(arr[*cur_it].y1 + 1, arr[*cur_it].y2, -1);
                    new_porb.add_req(*cur_it);
                }

                new_porb.rebuild_trees();
                return;
            }
        }

        assert(false);
    }

    bool cut() {
        int cut = tree_x.find_cut(arr[*st_x.begin()].x1 + 1, arr[*--st_x.end()].x1 + 1);

        if (cut == -1) {
            int cut = tree_y.find_cut(arr[*st_y.begin()].y1 + 1, arr[*--st_y.end()].y1 + 1);
            if (cut == -1) {
                return false;
            } else {
                do_cut(tree_y.get_real(cut), st_y, st_x, seg_y);
            }
        } else {
            do_cut(tree_x.get_real(cut), st_x, st_y, seg_x);
        }

        return true;
    }
};

prob probs[2 * MAX_N];

int main() {
#ifdef CH_EGOR
    freopen("input.txt", "r", stdin);
    //freopen("output.txt", "w", stdout);
#else
    //freopen("", "r", stdin);
    //freopen("", "w", stdout);
#endif

    for (int i = 0; i < 2 * MAX_N; ++i) {
        probs[i].probs = probs;
    }

    scanf("%d", &n);

    for (int i = 0; i < n; ++i) {
        scanf("%d%d%d%d", &arr[i].x1, &arr[i].y1, &arr[i].x2, &arr[i].y2);
        seg_x[i] = {arr[i].x1, arr[i].x2};
        seg_y[i] = {arr[i].y1, arr[i].y2};
    }

    for (int i = 0; i < n; ++i) {
        probs[0].add_req(i);
    }
    probs[0].rebuild_trees();

    cnt_prob = 1;
    for (int i = 0; i < cnt_prob; ++i) {
        while (!probs[i].full_cut()) {
            if (!probs[i].cut()) {
                no();
            }
        }
    }

    printf("YES\n");

    return 0;
}

