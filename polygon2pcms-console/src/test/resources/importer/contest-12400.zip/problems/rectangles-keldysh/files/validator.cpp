#include <bits/stdc++.h>
#include "testlib.h"
#define pb push_back
#define x first
#define y second
#define mp make_pair
#define len(a) int(a.size())
using namespace std;
        
typedef long long base; 
typedef pair<int, int> point;      
typedef complex<double> comp;

using namespace std;

const int N = 1e5;
//                   0 [samples],  1,  2,  3,    4,         5         
const int MAX_N[8] = {100 * 1000,  15, 25, 1000, 10 * 1000, 100 * 1000};
const int MAX_COOR = 1e9; 

int L[N][2], R[N][2];

set<pair<int, int>> cur;
vector<pair<int, int>> event;

bool cross(pair<int, int> a, pair<int, int> b) {
    return max(a.x, b.x) < min(a.y, b.y);
}

int main(int argc, char **argv) {
    registerValidation(argc, argv);
    //ensure(validator.group().size() == 1
    //         and validator.group()[0] >= '0'
    //         and validator.group()[0] <= '5');
    int group = validator.group()[0] - '0';
    if (!(0 <= group && group <= 5)) group = 0;
    int n = inf.readInt(1, MAX_N[group], "n");
    inf.readEoln();
    for (int i = 0; i < n; ++i) {
        L[i][0] = inf.readInt(0, MAX_COOR, "a_{i}");
        inf.readSpace();
        R[i][0] = inf.readInt(0, MAX_COOR, "b_{i}");
        inf.readSpace();
        L[i][1] = inf.readInt(0, MAX_COOR, "c_{i}");
        inf.readSpace();
        R[i][1] = inf.readInt(0, MAX_COOR, "d_{i}");
        inf.readEoln();
        event.pb({i, 0});
        event.pb({i, 1});
        ensuref(L[i][0] < L[i][1], "Wrong value of c_{i}: a_{i} >= c_{i}");
        ensuref(R[i][0] < R[i][1], "Wrong value of d_{i}: b_{i} >= d_{i}");
    }
    inf.readEof();
    sort(event.begin(), event.end(), [](pair<int, int> a, pair<int, int> b) {
        return make_pair(L[a.x][a.y], -a.y) < make_pair(L[b.x][b.y], -b.y);
    });
    
    for (int itR = 0; itR < event.size(); ++itR) {
        int id = event[itR].x;
        int t = event[itR].y;

        point seg = {R[id][0], R[id][1]};
        if (t) {
            cur.erase(seg);
        } else {
            auto it = cur.lower_bound(seg);
            if (it != cur.end()) {
                ensuref(!cross(seg, *it), "Rectangles are intersecting");
            }
            if (it != cur.begin()) {
                ensuref(!cross(seg, *prev(it)), "Rectangles are intersecting");
            }
            cur.insert(seg);
        }
    }
    
    return 0;
}


