#include <bits/stdc++.h>
#include "testlib.h"

using namespace std;

#define int long long

struct gr { int x1, y1, x2, y2; };

vector<gr> get_spiral(int x1, int y1, int x2, int y2, int n, int zip_factor, double part) {
	
	int mx = x2 - x1;
	int my = y2 - y1;

	vector< gr > v = { {0ll, 0ll, mx, my} };

	int tt = 0;
	for (int i = 1; i < n; ++i) {
		int pos = i - 1;
		if (tt == 0) {
			int mid = rnd.next(v[pos].y1 + 1, v[pos].y1 + 1 + (int)((v[pos].y2 - v[pos].y1 - 2) * part));
			v.push_back({v[pos].x1, mid, v[pos].x2, v[pos].y2 });
			v[pos] = {v[pos].x1, v[pos].y1, v[pos].x2, mid };
		} else if (tt == 2) {
			int mid = rnd.next(v[pos].y2 - 1 - (int)((v[pos].y2 - v[pos].y1 - 2) * part), v[pos].y2 - 1);
			v.push_back({v[pos].x1, mid, v[pos].x2, v[pos].y2 });
			v[pos] = {v[pos].x1, v[pos].y1, v[pos].x2, mid };
			swap(v[pos], v.back());
		} else if (tt == 1) {
			int mid = rnd.next(v[pos].x1 + 1, v[pos].x1 + 1 + (int)((v[pos].x2 - v[pos].x1 - 2) * part));
			v.push_back({mid, v[pos].y1, v[pos].x2, v[pos].y2 });
			v[pos] = {v[pos].x1, v[pos].y1, mid, v[pos].y2 };
		} else {
			int mid = rnd.next(v[pos].x2 - 1 - (int)((v[pos].x2 - v[pos].x1 - 2) * part), v[pos].x2 - 1);
			v.push_back({mid, v[pos].y1, v[pos].x2, v[pos].y2 });
			v[pos] = {v[pos].x1, v[pos].y1, mid, v[pos].y2 };
			swap(v[pos], v.back());
		}
		tt = (tt + 1) % 4;
	}

	for (int i = 0; i < n; ++i){
		int dx = max(0ll, v[i].x2 - v[i].x1 - 1);
		int dy = max(0ll, v[i].y2 - v[i].y1 - 1);
		dx = min(zip_factor, dx / 2);
		dy = min(zip_factor, dy / 2);
		v[i].x1 += rnd.next(0ll, dx);
		v[i].x2 -= rnd.next(0ll, dx);
		v[i].y1 += rnd.next(0ll, dy);
		v[i].y2 -= rnd.next(0ll, dy);
	}

	for (int i = 0; i < n; ++i) {
		v[i].x1 += x1;
		v[i].x2 += x1;
		v[i].y1 += y1;
		v[i].y2 += y1;
	}

	return v;
}

vector<gr> rand_gen(int x1, int y1, int x2, int y2, int n, int zip_factor) {

	int mx = x2 - x1;
	int my = y2 - y1;


	vector< gr > v = { {0ll, 0ll, mx, my} };

	for (int i = 1; i < n; ++i) {
		int pos = rnd.next(0ll, (int)v.size() - 1);
		while (v[pos].x2 - v[pos].x1 < 2 && v[pos].y2 - v[pos].y1 < 2) {
			pos = rnd.next(0ll, (int)v.size() - 1);
		}
		int tt = rnd.next(0, 1);
		if (tt) {
			if (v[pos].x2 - v[pos].x1 < 2) {
				int mid = rnd.next(v[pos].y1 + 1, v[pos].y2 - 1);
				v.push_back({v[pos].x1, mid, v[pos].x2, v[pos].y2 });
				v[pos] = {v[pos].x1, v[pos].y1, v[pos].x2, mid };
			} else {
				int mid = rnd.next(v[pos].x1 + 1, v[pos].x2 - 1);
				v.push_back({mid, v[pos].y1, v[pos].x2, v[pos].y2 });
				v[pos] = {v[pos].x1, v[pos].y1, mid, v[pos].y2 };
			}
		} else {
			if (v[pos].y2 - v[pos].y1 < 2) {
				int mid = rnd.next(v[pos].x1 + 1, v[pos].x2 - 1);
				v.push_back({mid, v[pos].y1, v[pos].x2, v[pos].y2 });
				v[pos] = {v[pos].x1, v[pos].y1, mid, v[pos].y2 };
			} else {
				int mid = rnd.next(v[pos].y1 + 1, v[pos].y2 - 1);
				v.push_back({v[pos].x1, mid, v[pos].x2, v[pos].y2 });
				v[pos] = {v[pos].x1, v[pos].y1, v[pos].x2, mid };
			}
		}
		
	}

	for (int i = 0; i < n; ++i){
		int dx = v[i].x2 - v[i].x1;
		int dy = v[i].y2 - v[i].y1;
		dx = min(zip_factor, dx / 2);
		dy = min(zip_factor, dy / 2);
		v[i].x1 += rnd.next(0ll, dx);
		v[i].x2 -= rnd.next(0ll, dx);
		v[i].y1 += rnd.next(0ll, dy);
		v[i].y2 -= rnd.next(0ll, dy);
	}

	for (int i = 0; i < n; ++i) {
		v[i].x1 += x1;
		v[i].x2 += x1;
		v[i].y1 += y1;
		v[i].y2 += y1;
	}

	return v;


}


signed main(signed argc, char* argv[]) {
	registerGen(argc, argv, 1);

	int cnt = atoi(argv[1]);
	int cnt_group = atoi(argv[2]);
	int mx = atoi(argv[3]);
	int my = atoi(argv[4]);
	int zip_factor = atoi(argv[5]);
	double part = stod(argv[6]);
	int min_s = atoi(argv[7]);
	double prob = stod(argv[8]);
	int type = atoi(argv[9]);



	vector< gr > rectangles;
	if (type == 1) {
		rectangles = get_spiral(0ll, 0ll, mx, my, cnt, zip_factor, part);
	} else {
		rectangles = rand_gen(0ll, 0ll, mx, my, cnt, zip_factor);
	}

	vector< gr > ans;
	for (int i = 0; i < cnt; ++i) {
		if ((rectangles[i].x2 - rectangles[i].x1) * (rectangles[i].y2 - rectangles[i].y1) < min_s) {
			continue;
		}
		if (rnd.next(0.0, 1.0) <= prob) {
			for (auto x : get_spiral(rectangles[i].x1, rectangles[i].y1, rectangles[i].x2, rectangles[i].y2, cnt_group, zip_factor, part)) {
				ans.push_back(x);
			}
		} else {
			for (auto x : rand_gen(rectangles[i].x1, rectangles[i].y1, rectangles[i].x2, rectangles[i].y2, cnt_group, zip_factor)) {
				ans.push_back(x);
			}
		}
	}
	
	shuffle(ans.begin(), ans.end());

	cout << ans.size() << endl;

	for (auto rect : ans) {
		cout << rect.x1 << " " << rect.y1 << " " << rect.x2 << " " << rect.y2 << '\n';
	}


	return 0;
}