#include <bits/stdc++.h>
#include "testlib.h"

using namespace std;

#define ft first
#define sd second
#define pb push_back
#define eb emplace_back
#define mp(a, b) make_pair(a, b)
#define pr(a, b, c) make_tuple(a, b, c)
#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()
#define sz(a) (int) a.size()
typedef long long ll;
typedef long double ld;
#define int long long

struct gr { int x1, y1, x2, y2; };

vector<gr> get_spiral(int x1, int y1, int x2, int y2, int n, int zip_factor, double part) {
	
	int mx = x2 - x1;
	int my = y2 - y1;

	vector< gr > v = { {0ll, 0ll, mx, my} };

	int tt = 0;
	for (int i = 1; i < n; ++i) {
		int pos = i - 1;
		if (tt == 0) {
			int mid = rnd.next(v[pos].y1 + 1, v[pos].y1 + 1 + (int)((v[pos].y2 - v[pos].y1 - 2) * part));
			v.push_back({v[pos].x1, mid, v[pos].x2, v[pos].y2 });
			v[pos] = {v[pos].x1, v[pos].y1, v[pos].x2, mid };
		} else if (tt == 2) {
			int mid = rnd.next(v[pos].y2 - 1 - (int)((v[pos].y2 - v[pos].y1 - 2) * part), v[pos].y2 - 1);
			v.push_back({v[pos].x1, mid, v[pos].x2, v[pos].y2 });
			v[pos] = {v[pos].x1, v[pos].y1, v[pos].x2, mid };
			swap(v[pos], v.back());
		} else if (tt == 1) {
			int mid = rnd.next(v[pos].x1 + 1, v[pos].x1 + 1 + (int)((v[pos].x2 - v[pos].x1 - 2) * part));
			v.push_back({mid, v[pos].y1, v[pos].x2, v[pos].y2 });
			v[pos] = {v[pos].x1, v[pos].y1, mid, v[pos].y2 };
		} else {
			int mid = rnd.next(v[pos].x2 - 1 - (int)((v[pos].x2 - v[pos].x1 - 2) * part), v[pos].x2 - 1);
			v.push_back({mid, v[pos].y1, v[pos].x2, v[pos].y2 });
			v[pos] = {v[pos].x1, v[pos].y1, mid, v[pos].y2 };
			swap(v[pos], v.back());
		}
		tt = (tt + 1) % 4;
	}

	for (int i = 0; i < n; ++i){
		int dx = max(0ll, v[i].x2 - v[i].x1 - 1);
		int dy = max(0ll, v[i].y2 - v[i].y1 - 1);
		dx = min(zip_factor, dx / 2);
		dy = min(zip_factor, dy / 2);
		v[i].x1 += rnd.next(0ll, dx);
		v[i].x2 -= rnd.next(0ll, dx);
		v[i].y1 += rnd.next(0ll, dy);
		v[i].y2 -= rnd.next(0ll, dy);
	}

	for (int i = 0; i < n; ++i) {
		v[i].x1 += x1;
		v[i].x2 += x1;
		v[i].y1 += y1;
		v[i].y2 += y1;
	}

	return v;
}

vector<gr> rand_gen(int x1, int y1, int x2, int y2, int n, int zip_factor) {

	int mx = x2 - x1;
	int my = y2 - y1;


	vector< gr > v = { {0ll, 0ll, mx, my} };

	for (int i = 1; i < n; ++i) {
		int pos = rnd.next(0ll, (int)v.size() - 1);
		while (v[pos].x2 - v[pos].x1 < 2 && v[pos].y2 - v[pos].y1 < 2) {
			pos = rnd.next(0ll, (int)v.size() - 1);
		}
		int tt = rnd.next(0, 1);
		if (tt) {
			if (v[pos].x2 - v[pos].x1 < 2) {
				int mid = rnd.next(v[pos].y1 + 1, v[pos].y2 - 1);
				v.push_back({v[pos].x1, mid, v[pos].x2, v[pos].y2 });
				v[pos] = {v[pos].x1, v[pos].y1, v[pos].x2, mid };
			} else {
				int mid = rnd.next(v[pos].x1 + 1, v[pos].x2 - 1);
				v.push_back({mid, v[pos].y1, v[pos].x2, v[pos].y2 });
				v[pos] = {v[pos].x1, v[pos].y1, mid, v[pos].y2 };
			}
		} else {
			if (v[pos].y2 - v[pos].y1 < 2) {
				int mid = rnd.next(v[pos].x1 + 1, v[pos].x2 - 1);
				v.push_back({mid, v[pos].y1, v[pos].x2, v[pos].y2 });
				v[pos] = {v[pos].x1, v[pos].y1, mid, v[pos].y2 };
			} else {
				int mid = rnd.next(v[pos].y1 + 1, v[pos].y2 - 1);
				v.push_back({v[pos].x1, mid, v[pos].x2, v[pos].y2 });
				v[pos] = {v[pos].x1, v[pos].y1, v[pos].x2, mid };
			}
		}
		
	}

	for (int i = 0; i < n; ++i){
		int dx = v[i].x2 - v[i].x1;
		int dy = v[i].y2 - v[i].y1;
		dx = min(zip_factor, dx / 2);
		dy = min(zip_factor, dy / 2);
		v[i].x1 += rnd.next(0ll, dx);
		v[i].x2 -= rnd.next(0ll, dx);
		v[i].y1 += rnd.next(0ll, dy);
		v[i].y2 -= rnd.next(0ll, dy);
	}

	for (int i = 0; i < n; ++i) {
		v[i].x1 += x1;
		v[i].x2 += x1;
		v[i].y1 += y1;
		v[i].y2 += y1;
	}

	return v;


}

vector<gr> gen_no(int x1, int y1, int x2, int y2, int pts, int len, int type, int inside, int zip_factor, double part, int cnt) {
	int mx = x2 - x1;
	int my = y2 - y1;

	vector<gr> v;

	v.push_back({ 0, 0, mx - len - 1, len });
	v.push_back({ mx - len, 0, mx, my - len - 1 });
	v.push_back({ len + 1, my - len, mx, my });
	v.push_back({ 0, len + 1, len, my });

	vector<int> ix;

	for (int i = 0; i < pts; ++i) {
		ix.push_back(rnd.next(len + 2, mx - len - 2));
	}

	sort(all(ix));
	ix.erase(unique(all(ix)), ix.end());

	if (ix.size() % 2) ix.pop_back();

	vector<int> tt[2];

	for (int i = 0; i < sz(ix); i += 2) {
		int t = rnd.next(0, 1);
		tt[t].push_back(ix[i]);
		tt[t].push_back(ix[i + 1]);
	}

	int prev = 0;

	vector<int> ids;
	ids.push_back(prev);

	for (int i = 0; i < tt[0].size(); i += 2) {
		v.push_back({ tt[0][i + 1], v[prev].y1, v[prev].x2, v[prev].y2 });
		v[prev] = { v[prev].x1, v[prev].y1, tt[0][i], v[prev].y2 };
		prev = v.size() - 1;
		ids.push_back(prev);
	}

	prev = 2;

	ids.push_back(prev);

	for (int i = 0; i < tt[1].size(); i += 2) {
		v.push_back({ tt[1][i + 1], v[prev].y1, v[prev].x2, v[prev].y2 });
		v[prev] = { v[prev].x1, v[prev].y1, tt[1][i], v[prev].y2 };
		prev = v.size() - 1;
		ids.push_back(prev);
	}

	/* shuffle(all(ids));

	for (int id : ids) {
		if (cnt) {
			cnt--;


			cerr << "FF" << v[prev].x1 << " " << v[prev].y1 << " " << v[prev].x2 << " " << v[prev].y2 << endl;

			int ym = v[prev].y1 + 1 + (v[prev].y2 - v[prev].y1) * rnd.next(0.0, 0.5);
			v.push_back({ v[prev].x1 + 1, v[prev].y1, v[prev].x2, ym });
			v[prev] = { v[prev].x1, ym, v[prev].x2 - 1, v[prev].y2 };

			cerr << "FF" << v[prev].x1 << " " << v[prev].y1 << " " << v[prev].x2 << " " << v[prev].y2 << endl;
			break;
		}
	} */


	vector<int> iy;

	for (int i = 0; i < pts; ++i) {
		iy.push_back(rnd.next(len + 2, mx - len - 2));
	}

	sort(all(iy));
	iy.erase(unique(all(iy)), iy.end());

	if (iy.size() % 2) iy.pop_back();

	tt[0].clear();
	tt[1].clear();

	for (int i = 0; i < sz(ix); i += 2) {
		int t = rnd.next(0, 1);
		tt[t].push_back(iy[i]);
		tt[t].push_back(iy[i + 1]);
	}

	prev = 1;

	for (int i = 0; i < tt[0].size(); i += 2) {
		v.push_back({ v[prev].x1, tt[0][i + 1], v[prev].x2, v[prev].y2 });
		v[prev] = { v[prev].x1, v[prev].y1, v[prev].x2, tt[0][i] };
		prev = v.size() - 1;
	}

	prev = 3;

	for (int i = 0; i < tt[1].size(); i += 2) {
		v.push_back({ v[prev].x1, tt[1][i + 1], v[prev].x2, v[prev].y2 });
		v[prev] = { v[prev].x1, v[prev].y1, v[prev].x2, tt[1][i] };
		prev = v.size() - 1;
	}

	if (type == 0) {
		for (auto rect : rand_gen(len + 1, len + 1, mx - len - 1, my - len - 1, inside, zip_factor)) {
			v.push_back(rect);
		}
	} else {
		cerr << "FF" << endl;
		for (auto rect : get_spiral(len + 1, len + 1, mx - len - 1, my - len - 1, inside, zip_factor, part)) {
			v.push_back(rect);
		}
	} 
	for (auto& r : v) {
		r.x1 += x1;
		r.y1 += y1;
		r.x2 += x1;
		r.y2 += y1;
	}
	return v;
}


signed main(signed argc, char* argv[]) {
	registerGen(argc, argv, 1);


	int pts = atoi(argv[1]);
	int mx = atoi(argv[2]);
	int my = atoi(argv[3]);
	int len = atoi(argv[4]);
	int type = atoi(argv[5]);
	int inside = atoi(argv[6]);
	int zip_factor = atoi(argv[7]);
	double part = stod(argv[8]);

	int cnt = atoi(argv[9]);
	int cnt1 = atoi(argv[10]);

	vector<gr> v = get_spiral(0ll, 0ll, mx, my, cnt1, zip_factor, part);

	int id = 0;

	for (int i = 0; i < sz(v); ++i) {
		if ((v[i].x2 - v[i].x1) * (v[i].y2 - v[i].y1) > (v[id].x2 - v[id].x1) * (v[id].y2 - v[id].y1)) {
			id = i;
		}
	}

	auto r = v[id];
	v.erase(v.begin() + id);

	for (auto rect : gen_no(r.x1, r.y1, r.x2, r.y2, pts, len, type, inside, zip_factor, part, cnt)) {
		v.push_back(rect);
	}
	
    shuffle(all(v));

	cout << v.size() << endl;

	for (auto rect : v) {
		cout << min(rect.x1, rect.x2) << " " << min(rect.y1, rect.y2) << " " << max(rect.x2, rect.x1) << " " << max(rect.y1, rect.y2) << '\n';
	}


	return 0;
}