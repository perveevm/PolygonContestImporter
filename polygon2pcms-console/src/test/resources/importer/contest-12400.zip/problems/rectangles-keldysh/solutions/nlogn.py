from functools import cmp_to_key

INF = int(1e9);

n = int(input())
rect = []
block = [[]]
max_coor = [[0, 0, 0, 0]]
block_id = []

def reset(id, d):
	global n, rect, block, block_id, max_coor
	max_coor[id][d] = -INF
	while len(block[id][d][1]):
		block[id][d][0].append(block[id][d][1][-1])
		block[id][d][1].pop()

def find_next(id, d):
	global n, rect, block, block_id, max_coor
	cur = block[id][d]
	while len(cur[0]):
		v = cur[0][-1];
		if block_id[v] != id:
			cur[0].pop()
			block[block_id[v]][d][0].append(v)
		else:
			if len(cur[1]) and max_coor[id][d] <= rect[v][d][0]:
				return True;
			max_coor[id][d] = max(max_coor[id][d], rect[v][d][1])
			cur[0].pop()
			cur[1].append(v)
			return False
	return False

def solve(id):
	global n, rect, block, block_id, max_coor
	for d in range(4):
		block[id][d][0].reverse()
	while True:
		for d in range(4):
			reset(id, d)
		found = False
		while len(block[id][0][0]) and not found:
			for d in range(4):
				if find_next(id, d):
					found = True;
					it = len(block)
					for j in block[id][d][1]:
						block_id[j] = it
					block.append([])
					for t in range(4):
						block[-1].append([[], []])
					max_coor.append([0, 0, 0, 0])
					break; 
		if found:
			continue
		for d in range(4):
			find_next(id, d);
		if len(block[id][0][1]) > 1:
			print("NO")
			exit(0);
		return

def main():
	global n, rect, block, block_id, max_coor
	for t in range(4):
		block[-1].append([[], []])
	for i in range(n):
		a, b, c, d = map(int, input().split())
		rect.append([(a, c), (b, d), (-c, -a), (-d, -b)])
		for t in range(4):
			block[0][t][0].append(i)
		block_id.append(0)
	for t in range(4):
		block[0][t][0].sort(key=lambda i : rect[i][t][0])
	i = 0
	while i < len(block):
		solve(i)
		i += 1
	print("YES")

main()


