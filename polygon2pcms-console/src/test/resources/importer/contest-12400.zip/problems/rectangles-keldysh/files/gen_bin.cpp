#include <bits/stdc++.h>
#include "testlib.h"

using namespace std;

#define ft first
#define sd second
#define pb push_back
#define eb emplace_back
#define mp(a, b) make_pair(a, b)
#define pr(a, b, c) make_tuple(a, b, c)
#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()
#define sz(a) (int) a.size()
typedef long long ll;
typedef long double ld;
#define int long long

struct gr { int x1, y1, x2, y2; };
struct ff { int x1, y1, x2, y2, type; };

signed main(signed argc, char* argv[]) {
	registerGen(argc, argv, 1);


	int n = atoi(argv[1]);
	int mx = atoi(argv[2]);
	int my = atoi(argv[3]);

	vector<gr> v;

	queue< ff > q;
	q.push({0, 0, mx, my, 0});

	while (q.size() < n) {
		int x1, y1, x2, y2, type;
		x1 = q.front().x1;
		x2 = q.front().x2;
		y1 = q.front().y1;
		y2 = q.front().y2;
		type = q.front().type;
		q.pop();
		if (type == 0) {
			int len = x2 - x1 + 1;
			int i1 = min(x2 - 1, x1 + ((int)(len * 0.25)) + 1);
			int i2 = max(x1 + 1, x2 - ((int)(len * 0.25)) - 1);
			if (i1 > i2) swap(i1, i2);
			int mid = rnd.next(i1, i2);
			q.push({x1, y1, mid, y2, type ^ 1});
			q.push({mid, y1, x2, y2, type ^ 1});
		} else {
			int len = y2 - y1 + 1;
			int i1 = min(y2 - 1, y1 + ((int)(len * 0.25)) + 1);
			int i2 = max(y1 + 1, y2 - ((int)(len * 0.25)) - 1);
			if (i1 > i2) swap(i1, i2);
			int mid = rnd.next(i1, i2);
			q.push({x1, y1, x2, mid, type ^ 1});
			q.push({x1, mid, x2, y2, type ^ 1});
		}
	}

	while (q.size()) {
		auto r = q.front();
		q.pop();
		v.push_back({r.x1, r.y1, r.x2, r.y2});
	}

    shuffle(all(v));

	cout << v.size() << endl;

	for (auto rect : v) {
		cout << rect.x1 << " " << rect.y1 << " " << rect.x2 << " " << rect.y2 << '\n';
	}

	return 0;
}