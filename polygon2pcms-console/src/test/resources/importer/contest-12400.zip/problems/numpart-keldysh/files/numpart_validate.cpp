#include "testlib.h"

using namespace std;

int main(int argc, char* argv[]) {
    registerValidation(argc, argv);

    int l = inf.readInt(2, 100000, "l");
    inf.readEoln();
    string s = inf.readToken("[1-9][0-9]*", "s");
    ensuref(s.length() == l, "unexpected length");
    
    int cnt = 0;
    for (int i = 1; i < l; ++i) {
        if (s[i] != '0') {
            ++cnt;
        }
    }
    ensuref(cnt > 0, "not enough non-zero digits");
    
    inf.readEoln();
    inf.readEof();
}
