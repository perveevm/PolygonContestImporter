from sys import argv
from random import *

n = int(argv[1])
z = int(argv[2])
seed(argv[-1])

if z > n - 1:
    exit(1)

nz = n - z
r = nz // 2
l = nz - r

a = []
for i in range(l):
    if i == 0:
        a.append(randint(1, 9))
    else:
        a.append(randint(0, 9))

for i in range(z):
    a.append(0)

for i in range(r):
    a.append(randint(0, 9))

print(len(a))
print(''.join(map(str, a)))
