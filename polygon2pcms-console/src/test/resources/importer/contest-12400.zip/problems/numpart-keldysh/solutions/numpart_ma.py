input()
s = input()
best = int(s)

if len(s) % 2 == 0 and s[len(s) // 2] != '0':
    best = min(best, int(s[:len(s) // 2]) + int(s[len(s) // 2:]))

for i in range(len(s) // 2 + 1, len(s)):
    if s[i] != '0':
        best = min(best, int(s[:i]) + int(s[i:]))
        break

for i in range((len(s) - 1) // 2, 0, -1):
    if s[i] != '0':
        best = min(best, int(s[:i]) + int(s[i:]))
        break

print(best)
