#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

void add(vector<int>& a, vector<int>& b) {
    if (a.size() < b.size()) {
        a.swap(b);
    }

    int cur = 0;
    for (int i = 0; i < a.size(); ++i) {
        cur += a[i];
        if (i < b.size()) {
            cur += b[i];
        }
        a[i] = cur % 10;
        cur /= 10;
    }
    while (cur > 0) {
        a.push_back(cur % 10);
        cur /= 10;
    }
}

bool cmp(const vector<int>& a, const vector<int>& b) {
    if (a.size() != b.size()) {
        return a.size() < b.size();
    }
    for (int i = (int) a.size() - 1; i >= 0; --i) {
        if (a[i] != b[i]) {
            return a[i] < b[i];
        }
    }
    return false;
}

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);

    int l;
    cin >> l;
    string s;
    cin >> s;
    int n = s.length();
    vector<int> d;
    for (int i = n - 1; i >= 0; --i) {
        d.push_back(s[i] - '0');
    }
    auto best = d;
    for (int i = 0; i < n - 1; ++i) {
        if (d[i] == 0) {
            continue;
        }

        vector<int> a, b;
        for (int j = 0; j <= i; ++j) {
            a.push_back(d[j]);
        }
        for (int j = i + 1; j < n; ++j)  {
            b.push_back(d[j]);
        }

        add(a, b);

        if (cmp(a, best)) {
            best = move(a);
        }
    }

    reverse(best.begin(), best.end());
    for (const auto& i : best) {
        cout << i;
    }
    cout << endl;

    return 0;
}
