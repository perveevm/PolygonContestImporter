#!/usr/bin/env bash
#   *** validation ***
scripts/run-validator-tests.sh
scripts/run-checker-tests.sh

#    *** tests ***
mkdir -p tests
echo "Generating test #3"
scripts/gen-input-via-stdout.sh "python3 files/gen_rand.pys3 2 0 91678778" "tests/03" 3
echo "Generating test #4"
scripts/gen-input-via-stdout.sh "python3 files/gen_rand.pys3 3 0 764271532" "tests/04" 4
echo "Generating test #5"
scripts/gen-input-via-stdout.sh "python3 files/gen_rand.pys3 6 0 908794811" "tests/05" 5
echo "Generating test #6"
scripts/gen-input-via-stdout.sh "python3 files/gen_rand.pys3 7 0 340750250" "tests/06" 6
echo "Generating test #7"
scripts/gen-input-via-stdout.sh "python3 files/gen_rand.pys3 9 0 611384768" "tests/07" 7
echo "Generating test #8"
scripts/gen-input-via-stdout.sh "python3 files/gen_rand.pys3 20 0 314955882" "tests/08" 8
echo "Generating test #9"
scripts/gen-input-via-stdout.sh "python3 files/gen_rand.pys3 30 0 676059430" "tests/09" 9
echo "Generating test #10"
scripts/gen-input-via-stdout.sh "python3 files/gen_rand.pys3 55 0 22183090" "tests/10" 10
echo "Generating test #11"
scripts/gen-input-via-stdout.sh "python3 files/gen_rand.pys3 76 0 130774413" "tests/11" 11
echo "Generating test #12"
scripts/gen-input-via-stdout.sh "python3 files/gen_rand.pys3 81 0 27888683" "tests/12" 12
echo "Generating test #13"
scripts/gen-input-via-stdout.sh "python3 files/gen_rand.pys3 99 0 423987612" "tests/13" 13
echo "Generating test #14"
scripts/gen-input-via-stdout.sh "python3 files/gen_rand.pys3 97 34 957347863" "tests/14" 14
echo "Generating test #15"
scripts/gen-input-via-stdout.sh "python3 files/gen_rand.pys3 100 50 295723558" "tests/15" 15
echo "Generating test #16"
scripts/gen-input-via-stdout.sh "python3 files/gen_mid_zeroes.pys3 99 40 308223317" "tests/16" 16
echo "Generating test #17"
scripts/gen-input-via-stdout.sh "python3 files/gen_mid_zeroes.pys3 100 90 204247614" "tests/17" 17
echo "Generating test #18"
scripts/gen-input-via-stdout.sh "python3 files/gen_rand.pys3 35432 0 375864620" "tests/18" 18
echo "Generating test #19"
scripts/gen-input-via-stdout.sh "python3 files/gen_rand.pys3 82398 0 668438763" "tests/19" 19
echo "Generating test #20"
scripts/gen-input-via-stdout.sh "python3 files/gen_rand.pys3 62811 0 792200989" "tests/20" 20
echo "Generating test #21"
scripts/gen-input-via-stdout.sh "python3 files/gen_rand.pys3 100000 0 848068667" "tests/21" 21
echo "Generating test #22"
scripts/gen-input-via-stdout.sh "python3 files/gen_rand.pys3 99989 0 304871863" "tests/22" 22
echo "Generating test #23"
scripts/gen-input-via-stdout.sh "python3 files/gen_rand.pys3 55151 0 732967748" "tests/23" 23
echo "Generating test #24"
scripts/gen-input-via-stdout.sh "python3 files/gen_rand.pys3 99999 12345 668647618" "tests/24" 24
echo "Generating test #25"
scripts/gen-input-via-stdout.sh "python3 files/gen_mid_zeroes.pys3 99999 12345 325344729" "tests/25" 25
echo "Generating test #26"
scripts/gen-input-via-stdout.sh "python3 files/gen_mid_zeroes.pys3 100000 50000 220661590" "tests/26" 26
echo "Generating test #27"
scripts/gen-input-via-stdout.sh "python3 files/gen_mid_zeroes.pys3 100000 10000 311636455" "tests/27" 27
echo ""
echo "Generating answer for test #1"
scripts/gen-answer.sh tests/01 tests/01.a "tests" "0"
echo ""
echo "Generating answer for test #2"
scripts/gen-answer.sh tests/02 tests/02.a "tests" "0"
echo ""
echo "Generating answer for test #3"
scripts/gen-answer.sh tests/03 tests/03.a "tests" "1"
echo ""
echo "Generating answer for test #4"
scripts/gen-answer.sh tests/04 tests/04.a "tests" "1"
echo ""
echo "Generating answer for test #5"
scripts/gen-answer.sh tests/05 tests/05.a "tests" "1"
echo ""
echo "Generating answer for test #6"
scripts/gen-answer.sh tests/06 tests/06.a "tests" "1"
echo ""
echo "Generating answer for test #7"
scripts/gen-answer.sh tests/07 tests/07.a "tests" "1"
echo ""
echo "Generating answer for test #8"
scripts/gen-answer.sh tests/08 tests/08.a "tests" "1"
echo ""
echo "Generating answer for test #9"
scripts/gen-answer.sh tests/09 tests/09.a "tests" "1"
echo ""
echo "Generating answer for test #10"
scripts/gen-answer.sh tests/10 tests/10.a "tests" "1"
echo ""
echo "Generating answer for test #11"
scripts/gen-answer.sh tests/11 tests/11.a "tests" "1"
echo ""
echo "Generating answer for test #12"
scripts/gen-answer.sh tests/12 tests/12.a "tests" "1"
echo ""
echo "Generating answer for test #13"
scripts/gen-answer.sh tests/13 tests/13.a "tests" "1"
echo ""
echo "Generating answer for test #14"
scripts/gen-answer.sh tests/14 tests/14.a "tests" "1"
echo ""
echo "Generating answer for test #15"
scripts/gen-answer.sh tests/15 tests/15.a "tests" "1"
echo ""
echo "Generating answer for test #16"
scripts/gen-answer.sh tests/16 tests/16.a "tests" "1"
echo ""
echo "Generating answer for test #17"
scripts/gen-answer.sh tests/17 tests/17.a "tests" "1"
echo ""
echo "Generating answer for test #18"
scripts/gen-answer.sh tests/18 tests/18.a "tests" "1"
echo ""
echo "Generating answer for test #19"
scripts/gen-answer.sh tests/19 tests/19.a "tests" "1"
echo ""
echo "Generating answer for test #20"
scripts/gen-answer.sh tests/20 tests/20.a "tests" "1"
echo ""
echo "Generating answer for test #21"
scripts/gen-answer.sh tests/21 tests/21.a "tests" "1"
echo ""
echo "Generating answer for test #22"
scripts/gen-answer.sh tests/22 tests/22.a "tests" "1"
echo ""
echo "Generating answer for test #23"
scripts/gen-answer.sh tests/23 tests/23.a "tests" "1"
echo ""
echo "Generating answer for test #24"
scripts/gen-answer.sh tests/24 tests/24.a "tests" "1"
echo ""
echo "Generating answer for test #25"
scripts/gen-answer.sh tests/25 tests/25.a "tests" "1"
echo ""
echo "Generating answer for test #26"
scripts/gen-answer.sh tests/26 tests/26.a "tests" "1"
echo ""
echo "Generating answer for test #27"
scripts/gen-answer.sh tests/27 tests/27.a "tests" "1"
echo ""

