input()
s = input()
best = int(s)
for i in range(1, len(s)):
    if s[i] != '0':
        best = min(best, int(s[:i]) + int(s[i:]))
print(best)
