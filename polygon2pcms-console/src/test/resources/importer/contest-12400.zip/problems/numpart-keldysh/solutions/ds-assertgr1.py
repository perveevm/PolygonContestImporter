#!/usr/bin/python3
# Dmitry _kun_ Sayutin (2019)

import sys

l = int(input())
num = input().strip()

if l > 9 or '0' in num:
    sys.exit(1)

ans = []

# 01234

# 0123

p0, p1 = None, None

if len(num) % 2 == 0:
    p0, p1 = len(num) // 2, len(num) // 2
else:
    p0, p1 = (len(num) - 1) // 2, (len(num) + 1) // 2

flg0, flg1 = False, False

for len1 in range(p0, 0, -1):
    if num[len1] != '0':
        ans.append(int(num[:len1]) + int(num[len1:]))

        if flg0:
            break
        flg0 = True

for len1 in range(p1, len(num)):
    if num[len1] != '0':
        ans.append(int(num[:len1]) + int(num[len1:]))

        if flg1:
            break
        flg1 = True

print(min(ans))
