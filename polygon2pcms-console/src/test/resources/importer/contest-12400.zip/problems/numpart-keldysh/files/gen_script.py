from random import *

seed('2y4teqrafdcvfsbgjeusetrghvne7uw434wtyhn')

def rnd():
    return randint(1, 10 ** 9)


# l <= 9
print('gen_rand', 2, 0, rnd(), '> $')
print('gen_rand', 3, 0, rnd(), '> $')
print('gen_rand', 6, 0, rnd(), '> $')
print('gen_rand', 7, 0, rnd(), '> $')
print('gen_rand', 9, 0, rnd(), '> $')

# l <= 100, no zeroes
print('gen_rand', 20, 0, rnd(), '> $')
print('gen_rand', 30, 0, rnd(), '> $')
print('gen_rand', 55, 0, rnd(), '> $')
print('gen_rand', 76, 0, rnd(), '> $')
print('gen_rand', 81, 0, rnd(), '> $')
print('gen_rand', 99, 0, rnd(), '> $')

# l <= 100
print('gen_rand', 97, 34, rnd(), '> $')
print('gen_rand', 100, 50, rnd(), '> $')
print('gen_mid_zeroes', 99, 40, rnd(), '> $')
print('gen_mid_zeroes', 100, 90, rnd(), '> $')

# no zeroes
print('gen_rand', 35432, 0, rnd(), '> $')
print('gen_rand', 82398, 0, rnd(), '> $')
print('gen_rand', 62811, 0, rnd(), '> $')
print('gen_rand', 100000, 0, rnd(), '> $')
print('gen_rand', 99989, 0, rnd(), '> $')
print('gen_rand', 55151, 0, rnd(), '> $')

#
print('gen_rand', 99999, 12345, rnd(), '> $')
print('gen_mid_zeroes', 99999, 12345, rnd(), '> $')
print('gen_mid_zeroes', 100000, 50000, rnd(), '> $')
print('gen_mid_zeroes', 100000, 10000, rnd(), '> $')
