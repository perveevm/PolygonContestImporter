#include <iostream>

using namespace std;

int pref(int n, int l) {
    for (int i = 0; i < l; ++i) {
        n /= 10;
    }
    return n;
}

int suf(int n, int l) {
    int p = 1;
    for (int i = 0; i < l; ++i) {
        p *= 10;
    }
    return n % p;
}

int main() {
    int l;
    cin >> l;
    int n;
    cin >> n;

    int ans = n;
    for (int i = 1; i < l; ++i) {
        ans = min(ans, pref(n, i) + suf(n, i));
    }

    cout << ans << endl;

    return 0;
}