from sys import argv
from random import *

n = int(argv[1])
z = int(argv[2])
seed(argv[-1])

if z > n - 1:
    exit(1)

nz = set()
nz.add(0)
while len(nz) + z < n:
    nz.add(randint(0, n - 1))

a = []
for i in range(n):
    if i in nz:
        a.append(randint(1, 9))
    else:
        a.append(0)

print(len(a))
print(''.join(map(str, a)))
