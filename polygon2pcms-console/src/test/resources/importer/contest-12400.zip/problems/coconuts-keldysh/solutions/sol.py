x, y, z = map(int, input().split())
ans = x // z + y // z + (1 if x % z + y % z >= z else 0)
debt = z - max(x % z, y % z) if x % z + y % z >= z else 0
print(ans, debt)