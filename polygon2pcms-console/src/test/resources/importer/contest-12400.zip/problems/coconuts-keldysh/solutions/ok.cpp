#include <iostream>

using namespace std;

int main() {
    long long x, y, z;
    cin >> x >> y >> z;
    long long ans = x / z + y / z;
    long long debt = 0;
    if (x % z + y % z >= z) {
        ++ans;
        debt = z - max(x % z, y % z);
    }
    cout << ans << " " << debt << "\n";
    return 0;
}