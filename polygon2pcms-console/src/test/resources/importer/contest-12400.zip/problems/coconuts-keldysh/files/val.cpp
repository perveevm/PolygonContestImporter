#include "testlib.h"

using namespace std;

const long long MX = static_cast<long long>(1e18);

int main(int argc, char **argv) {
    registerValidation(argc, argv);
    long long x = inf.readLong(0, MX, "x");
    inf.readSpace();
    long long y = inf.readLong(0, MX, "y");
    inf.readSpace();
    long long z = inf.readLong(1, MX, "z");
    inf.readEoln();
    inf.readEof();
}
