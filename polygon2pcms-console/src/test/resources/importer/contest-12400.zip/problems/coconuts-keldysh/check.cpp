#include "testlib.h"
#include <iostream>

using namespace std;

bool ok(long long cnt, long long debt, long long x, long long y, long long z) {
    x += debt, y -= debt;
    return x >= 0 && y >= 0 && x / z + y / z == cnt;
}

pair<long long, long long> check(InStream& in, long long x, long long y, long long z) {
    long long cnt = in.readLong();
    long long debt = in.readLong(0, max(x, y));
    if (ok(cnt, debt, x, y, z) || ok(cnt, -debt, x, y, z)) {
        return {-cnt, debt};
    }
    in.quitf(_wa, "Impossible scenario\n");
}

int main(int argc, char* argv[]) {
    registerTestlibCmd(argc, argv);
    long long x = inf.readLong();
    long long y = inf.readLong();
    long long z = inf.readLong();
    auto pa = check(ouf, x, y, z);
    auto ja = check(ans, x, y, z);
    if (pa < ja) {
        quitf(_fail, "The participant has a better answer: %lld, %lld is better than %lld, %lld\n", -pa.first, pa.second, -ja.first, ja.second);
    } else if (pa > ja) {
        quitf(_wa, "The jury has a better answer: %lld, %lld is better than %lld, %lld\n", -ja.first, ja.second, -pa.first, pa.second);
    } else {
        quitf(_ok, "Bought %lld coconuts, debt is %lld\n", -ja.first, ja.second);
    }
}