echo [INFO]: Wiping problem 'coconuts-keldysh'.
cd problems/coconuts-keldysh
./wipe.sh
cd -

echo [INFO]: Wiping problem 'numpart-keldysh'.
cd problems/numpart-keldysh
./wipe.sh
cd -

echo [INFO]: Wiping problem 'flag-keldysh'.
cd problems/flag-keldysh
./wipe.sh
cd -

echo [INFO]: Wiping problem 'ioi-place-keldysh'.
cd problems/ioi-place-keldysh
./wipe.sh
cd -

echo [INFO]: Wiping problem 'rectangles-keldysh'.
cd problems/rectangles-keldysh
./wipe.sh
cd -

echo [INFO]: Wiping russian contest statement.
cd statements/russian
./wipe.sh
cd -

