cd ../../problems/coconuts-keldysh/statements/russian
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/numpart-keldysh/statements/russian
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/flag-keldysh/statements/russian
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/ioi-place-keldysh/statements/russian
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/rectangles-keldysh/statements/russian
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
